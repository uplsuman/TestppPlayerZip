import * as express from "express";
import { logger } from "shared/src/logger";
import playlistModel from "./model";
import axios from "axios";
import config from "../config";
import { downloadMedia } from "../utils/downloadMedia";
import dir from "../configPath";
import { db } from "../utils/db";
import socketConnection from "../io";




const filePath = dir.mediaPath;
const fs = require("fs");

const router = express.Router();

/**
 * @type - POST
 * @route -  /api/playlists
 * @desc - route for prices.
 * @access - PUBLIC
 * @function - priceList
 */

const getLocalFiles = async (filePath: string) => {
  return new Promise(async function (resolve, reject) {
    await fs.readdir(filePath, function (err: any, files: any) {
      if (err) {
        reject("Unable to scan directory: " + err);
      } else {
        resolve(files);
      }
    });
  });
};

const removeLocalFile = async (result: any, localFiles: any) => {
  for (let i = 0; i < localFiles.length; i++) {
    const index = result.findIndex((x: string) => x == localFiles[i])
    if (index === -1) {
      let path = `${filePath}/${localFiles[i]}`
      if (fs.existsSync(path)) {
        await fs.unlinkSync(path);
      }
    }
  }
};

router.post("/", async (req, res) => {
  try {
    const playlist = new playlistModel({
      deviceId: req.body.deviceId,
      mediaArr: req.body.mediaArr,
      active: true,
      publishedAt: Date.now(),
    });

    const savedPlaylist = await playlist.save();

    return res.status(200).send({
      error: false,
      message: "playlist saved successfully",
      result: savedPlaylist._id,
    });
  } catch (err) {
    return res.status(500).send({
      error: true,
      message: "Internal server error",
    });
  }
});

/**
 * @type - GET
 * @route -  /api/playlists
 * @desc - route for prices.
 * @access - PUBLIC
 * @function - priceList
 */

router.get("/", async (req, res) => {
  try {
    if (!fs.existsSync(filePath)) {
      fs.mkdirSync(filePath);
    }
    let allFiles: any = await getLocalFiles(filePath);
    let deviceId = req.query.deviceId

    const jsonData = await db.getData("/");
    let arr: any[] = []
    if (jsonData?.playlist?.albumArr?.length > 0) {
      // let activeIndex = await db.getIndex("/playlist", "active", "status");
      let playlist = await db.getData("/playlist");
      let mediaArr: any[] = []
      const requests = playlist.albumArr.map(async (x: any) => {
        // const requests = playlist[activeIndex].albumArr.map(async (x: any) => {
        let obj: any = {};
        obj.albumName = x.name;
        const result: any = await axios.get(
          `${config.mediaUrl}/medias/mediafiles/${x.albumId}`
        );
        if (result.data) {
          result.data.result.map(async (y: any) => {
            const ext: any = /(?:\.([^.]+))?$/.exec(y?.name || y?.mediaFile?.name);
            const url = `${process.env.mediaurl}/uploads/?key=${y?.mediaFile?.key}`;
            const path = `${filePath}/${y._id}${ext[0]}`;
            mediaArr.push(`${y._id}${ext[0]}`)
            const io = socketConnection.get()
            if (allFiles?.length > 0) {
              if (!fs.existsSync(path)) {
                await downloadMedia(url, path, async () => {
                  console.log(`✅ ${y._id}${ext[0]} download Done!`);
                  await io.to(deviceId).emit("publish", {
                    message: "download Done",
                    result: {
                      type: "DOWNLOAD",
                      key: `${y._id}${ext[0]}`
                    },
                  });
                });
              }
            } else {
              await downloadMedia(url, path, async () => {
                console.log(`✅ ${y._id}${ext[0]} download Done!`);
                await io.to(deviceId).emit("publish", {
                  message: "download Done",
                  result: {
                    type: "DOWNLOAD",
                    key: `${y._id}${ext[0]}`
                  },
                });
              });
            }
          });
        }
      })



      Promise.all(requests).then(async () => {
        allFiles = await getLocalFiles(filePath);

        if (allFiles?.length > 0 && mediaArr?.length > 0) {
          await removeLocalFile(mediaArr, allFiles)
        }

        return res.status(200).send({
          error: false,
          message: "playlist found successfully",
          result: allFiles,
          code: "MEDIA_FOUND",
        });

      });
    }
    else {
      return res.status(200).send({
        error: false,
        message: "No content found",
        result: [],
        code: "NO_CONTENT",
      });
    }
  } catch (err) {
    console.log(err, "Playlist error");
    return res.status(500).send({
      error: true,
      message: "Internal server error",
      code: "INTERNAL_SERVER_ERROR",
    });
  }
});

/**
 * @type - GET
 * @route -  /api/medias
 * @desc - route for prices.
 * @access - PUBLIC
 * @function - priceList
 */

router.get("/images", async (req, res) => {
  try {
    if (req.query.key) {
      const path = `${filePath}/${req.query.key}`
      console.log('path===>', path)
      if (fs.existsSync(path)) {
        res.writeHead(200, {
          "Content-Type": "application/octet-stream",
          "Content-Disposition": "attachment; filename=" + req.query.key
        });
        fs.createReadStream(path).pipe(res);
        return;
      }


    } else {
      return res.status(200).send({
        error: false,
        message: "No content found",
        result: [],
        code: "NO_CONTENT",
      });
    }
  } catch (err) {
    console.log(err, "Playlist error");
    return res.status(500).send({
      error: true,
      message: "Internal server error",
      code: "INTERNAL_SERVER_ERROR",
    });
  }
});
// router.get("/", async (req, res) => {
//     try {
//         const mediaArr = req.body.mediaArr;

//         // await Promise.all(mediaArr.map(async (media: { key: string }) => {

//         // }))
//     }
//     catch (err) {
//         logger.error(err)
//         return res.status(500).send({
//             error: true,
//             message: "Error While downloading media",
//             code: "INTERNAL_SERVER_ERROR"
//         });
//     }
// })

export default router;
