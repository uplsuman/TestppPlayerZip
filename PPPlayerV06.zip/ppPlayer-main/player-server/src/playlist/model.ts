
// @ts-check
import * as mongoose from "mongoose";
let Schema = mongoose.Schema;

const deviceSchema = new Schema({
    name: {
        type: String,
    },
    deviceId: {
        type: String,
    },
    deviceObjectId: {
        type: String,
    },
    playlistId: {
        type: String,
    },
    publishedAt: {
        type: Number,
        default: Date.now,
    },
    active: {
        type: Boolean
    },
    updatedAt: {
        type: Number,
        default: Date.now,
    },
    albumArr: [
        {
            name: {
                type: String
            },
            albumId: {
                type: String
            },
            mediaArr: [
                {
                    type: String
                }
            ]
        }
    ]
});


export default mongoose.model("playlist", deviceSchema);
