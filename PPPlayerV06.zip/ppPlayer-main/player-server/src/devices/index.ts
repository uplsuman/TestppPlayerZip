import * as express from "express";
import DeviceModel from "./deviceModel";
import { customAlphabet } from "nanoid";
import { logger } from "shared/src/logger";
import { promisify } from "util";
import dir from "../configPath"
import { db } from "../utils/db";


const exec = require("child_process");
const checkInternetConnected = require("check-internet-connected");
const execPromise = promisify(exec.exec);

// const db = new JsonDB(new Config("myDataBase", true, false, '/'));


const router = express.Router();

function getDeviceId() {
  const nanoidA = customAlphabet("PICTPLAY", 1);
  const nanoid = customAlphabet("1234567890", 5);
  let IdA = nanoidA();
  let Id = nanoid();
  Id = IdA + Id;
  return Id;
}
/**
 * @type - POST
 * @route -  /api/devices/register
 * @desc - route for device register.
 * @access - PUBLIC
 */

router.post("/register", async (req, res) => {
  try {
    // DeviceModel.findOne({
    //   serialNumber: req.body.serialNumber,
    //   enable: true,
    // }).then(async (deviceData: any) => {
    //   console.log(deviceData);
    //   if (deviceData) {
    //     return res.status(200).send({
    //       error: false,
    //       message: "Device already registered.",
    //       result: deviceData,
    //       code: "DEVICE_ALREADY_REGISTERED",
    //     });
    //   } else {
    //     const Id = await getDeviceId();

    //     const device = new DeviceModel({
    //       serialNumber: req.body.serialNumber,
    //       createdAt: Date.now(),
    //       deviceId: Id,
    //     });

    //     const newDevice = await device.save();
    let data: any = await db.getData("/");
    if (data?.device?.deviceId) {
      return res.status(200).send({
        error: false,
        message: "Device already registered.",
        result: data.device,
        code: "DEVICE_ALREADY_REGISTERED",
      });
    }
    else {
      const Id = await getDeviceId();
      db.push("/device", {
        serialNumber: req.body.serialNumber,
        createdAt: Date.now(),
        deviceId: Id,
      }, true);

      return res.status(200).send({
        error: false,
        message: "Device is registered successfully",
        result: { serialNumber: req.body.serialNumber, deviceId: Id },
        code: "DEVICE_ADDED",
      });
    }

  } catch (err) {
    console.log('error=====>', err)
    return res.status(500).send({
      error: true,
      message: "Internal server error",
    });
  }
});



/**
 * @type - GET
 * @route -  /api/devices/serial
 * @desc - route for prices.
 * @access - PUBLIC
 * @function - priceList
 */

router.get("/serial", async (req, res) => {
  try {
    const serial = await execPromise(
      "cat /proc/cpuinfo | grep Serial | cut -d ' ' -f 2"
    );
    const onlySerial = serial.stdout.trim();
    return res.status(200).send({
      error: false,
      message: "Device serial number get successfully",
      result: onlySerial,
    });
  } catch (err) {
    console.log(err, "error");
    return res.status(500).send({
      error: true,
      message: "Internal server error",
    });
  }
});

/**
 * @type - GET
 * @route -  /api/devices/serial
 * @desc - route for prices.
 * @access - PUBLIC
 * @function - priceList
 */

router.put("/update", async (req, res) => {
  try {
    DeviceModel.findOne({
      serialNumber: req.body.serialNumber,
      enable: true,
    }).then(async (deviceData: any) => {
      if (deviceData) {
        let updatedDevice = await DeviceModel.findByIdAndUpdate(
          deviceData._id,
          { $set: { updatedAt: Date.now(), user: req.body.user } },
          { new: true }
        );
        return res.status(200).send({
          error: false,
          message: "Device updated successfully",
          result: updatedDevice,
        });
      } else {
        return res.status(200).send({
          error: false,
          message: "Device not found",
          result: deviceData,
        });
      }
    });
  } catch (err) {
    return res.status(500).send({
      error: true,
      message: "Internal server error",
    });
  }
});

export default router;
