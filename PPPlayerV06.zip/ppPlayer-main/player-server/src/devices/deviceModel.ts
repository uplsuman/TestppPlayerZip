// @ts-check
import * as mongoose from "mongoose";
let Schema = mongoose.Schema;

const deviceSchema = new Schema({
  serialNumber: {
    type: String,
  },
  deviceId: {
    type: String,
  },
  objectId: {
    type: String,
  },
  userId: {
    type: String,
  },
  status: {
    type: String,
    enum: ["online", "offline"],
    default: "offline",
  },
  temperature: {
    type: Number,
  },
  lastOnline: {
    type: Number,
  },
  createdAt: {
    type: Number,
    default: Date.now,
  },
  updatedAt: {
    type: Number,
    default: Date.now,
  },
  enable: {
    type: Boolean,
    default: true,
  },
  user: {
    name: {
      type: String,
    },
    email: {
      type: String,
    }
  }
});


export default mongoose.model("device", deviceSchema);
