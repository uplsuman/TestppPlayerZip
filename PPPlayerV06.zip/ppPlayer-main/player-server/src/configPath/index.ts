var path = require("path");
var appDir = path.dirname(require?.main?.filename);

export default {
  appPath: appDir,
  mediaPath: path.join(__dirname, "../../../data/media"),
  dataPath: path.join(__dirname, "../../../data"),
};
