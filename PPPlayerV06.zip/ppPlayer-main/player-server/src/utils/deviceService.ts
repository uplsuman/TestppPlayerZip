import { logger } from "shared/src/logger";
import { db } from "../utils/db";
import fs from 'fs';
import dir from "../configPath";

export function checkPortalRegistration(data: any, io: any) {
  return new Promise(async function (resolve, reject) {
    try {
      logger.info("Create device", data);
      // const deviceData = await deviceModel.findOne({
      //   deviceId: data.deviceId,
      //   enable: true,
      // });
      let deviceData: any = await db.getData("/");
      if (deviceData?.device) {
        let device: any = deviceData?.device;
        if (device?.deviceId === data.deviceId) {
          db.push(
            "/device",
            {
              user: data.user,
              id: data.objectId,
              userId: data.userId,
            },
            false
          );
        }
        // let device: any = deviceData.device
        // device['user'] = data.user
        // device['id'] = data.objectId
        // device['userId'] = data.userId
        // await deviceModel.findByIdAndUpdate(
        //   deviceData._id,
        //   {
        //     $set: {
        //       user: data.user,
        //       updatedAt: Date.now(),
        //       objectId: data.objectId,
        //       userId: data.userId,
        //     },
        //   },
        //   { new: true }
        // );
        let socketRoom = `${data.deviceId}`;
        io.to(socketRoom).emit("deviceNotification", {
          message: "Device added to portal",
          result: data,
        });
      }
      resolve("Device added to portal");
    } catch (err) {
      console.log("error===>", err);
      reject("Error in Updating device");
    }
  });
}

export function checkDeleteFromPortal(data: any, io: any) {
  return new Promise(async function (resolve, reject) {
    try {
      logger.info("delete device", data);
      let deviceData: any = await db.getData("/device");
      const filePath = dir.mediaPath;
      if (deviceData?.id === data.objectId) {
        await db.delete('/');
        if (fs.existsSync(filePath)) {
          fs.rmdirSync(filePath, { recursive: true });
        }
        let socketRoom = `${data.deviceId}`;
        io.to(socketRoom).emit("publish", {
          message: "Device deleted to portal",
          result: "DEVICE_DELETE",
        });
      }
      resolve("Device delete to portal");
    } catch (err) {
      console.log("error===>", err);
      reject("Error in deleting device");
    }
  });
}
