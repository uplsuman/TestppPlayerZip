import playlistModel from "../playlist/model";
import fs from "fs";
import AWS from "aws-sdk";
import dir from "../configPath";
import { logger } from "shared/src/logger";
import deviceModel from "../devices/deviceModel";
import { db } from "../utils/db";

const { exec, execSync } = require("child_process");

// export function createPlaylist(data: any, io: any) {
//     return new Promise(async function (resolve, reject) {
//         try {
//             // const device = await deviceModel.findOne({ objectId: data.deviceObjectId, enable: true })
//             const jsonData = await db.getData("/");
//             // await db.delete("/playlist");
//             if (jsonData?.device?.id === data.deviceObjectId) {
//                 if (jsonData?.playlist) {
//                     await db.delete("/playlist[]");
//                     let existingIndex = await db.getIndex("/playlist", data.playlistId);
//                     logger.info("existingIndex", existingIndex);
//                     const filePath = dir.mediaPath;
//                     let media
//                     if (fs.existsSync(filePath)) {
//                         media=fs.rmdirSync(filePath, { recursive: true });
//                     }
//                     console.log(media,"<<-madia")
//                     if (existingIndex > -1) {
//                         db.delete(`/playlist[${existingIndex}]`);
//                         // await db.delete("/playlist");
//                         await db.push(
//                             `/playlist[${existingIndex}]`,
//                             {
//                                 name: data.name || "Default",
//                                 albumArr: data.mediaArr,
//                                 status: "active",
//                                 publishedAt: Date.now(),
//                                 id: data.playlistId,
//                             },
//                             true
//                         );
//                     } else {
//                         logger.info("call2");
//                         await addPlaylist(data);
//                     }
//                 } else {
//                     logger.info("call3");
//                     await addPlaylist(data);
//                 }
//                 // const existingData = await playlistModel.findOne({ deviceObjectId: data.deviceObjectId })
//                 // if (existingData) {
//                 //     logger.info('update playlist', existingData)
//                 //     existingData.playlistId = data.playlistId
//                 //     existingData.name = data.name || "Default"
//                 //     existingData.albumArr = data.albumArr
//                 //     existingData.publishedAt = Date.now()
//                 //     await existingData.save()
//                 // }
//                 // else {
//                 //     const playlist = new playlistModel({
//                 //         name: data.name || "Default",
//                 //         deviceId: device.deviceId,
//                 //         albumArr: data.albumArr,
//                 //         active: true,
//                 //         publishedAt: Date.now(),
//                 //         playlistId: data.playlistId,
//                 //         deviceObjectId: data.deviceObjectId
//                 //     });
//                 //     await playlist.save();
//                 io.to(`${jsonData?.device?.deviceId}`).emit("publish", {
//                     message: "playlist published from portal",
//                     result: "PUBLISHED",
//                 });

//                 //     logger.info('create playlist', playlist)
//                 // }
//                 resolve("playlist added");
//             } else {
//                 logger.info("Device not found");
//                 reject("Device not found");
//             }
//         } catch (err) {
//             console.log("error===>", err);
//             reject("Error in Updating device");
//         }
//     });
// }


export function createPlaylist(data: any, io: any) {
    return new Promise(async function (resolve, reject) {
        try {
            const jsonData = await db.getData("/");
            if (jsonData?.device?.id === data.deviceObjectId) {
                const filePath = dir.mediaPath;
                if (fs.existsSync(filePath)) {
                    await fs.rmdirSync(filePath, { recursive: true });
                }
                if (jsonData?.playlist) {
                    await db.delete("/playlist");
                }

                await db.push("/playlist", {
                    name: data.name || "Default",
                    albumArr: data.mediaArr,
                    status: "active",
                    publishedAt: Date.now(),
                    id: data.playlistId,
                }, true);

                await io.to(`${jsonData?.device?.deviceId}`).emit("publish", {
                    message: "playlist published from portal",
                    result: "PUBLISHED",
                });

            }
        } catch (err) {
            console.log("error===>", err);
            reject("Error in creating playlist");
        }
    });
}


const addPlaylist = async (data: any) => {
    await db.push(
        "/playlist[]",
        {
            name: data.name || "Default",
            albumArr: data.mediaArr,
            status: "active",
            publishedAt: Date.now(),
            id: data.playlistId,
        },
        true
    );
};

export function updateDevicePlaylist(data: any) {
    return new Promise(async function (resolve, reject) {
        try {
            const playlist = await playlistModel.findOne({
                deviceObjectId: data.objectId,
                playlistId: data.playlistId,
            });
            if (playlist) {
                logger.info("actiontype", data.actionType);
                const albumArr = playlist.albumArr;
                const index = albumArr.findIndex(
                    (x: any) => x.albumId.toString() === data.albumId.toString()
                );
                if (index > -1) {
                    if (
                        data.actionType === "albumRemove" ||
                        data.actionType === "albumDelete"
                    ) {
                        albumArr.splice(index, 1);
                    } else if (data.actionType === "mediaRemove") {
                        albumArr[index].mediaArr = albumArr[index].mediaArr.filter(
                            (z: any) => {
                                return z.toString() !== data.data.toString();
                            }
                        );
                    } else {
                        albumArr[index].mediaArr = [
                            ...albumArr[index].mediaArr,
                            ...data.data,
                        ];
                    }
                } else {
                    if (data.actionType === "albumAdd") {
                        albumArr.push(data.data);
                    }
                }

                playlist.albumArr = albumArr;
                playlist.updatedAt = Date.now();
                logger.info("albumArr", playlist.albumArr);

                await playlist.save();
                resolve("Playlist updated");
            }
        } catch (err) {
            logger.info("error===>", err);
            reject("Error in Updating device");
        }
    });
}
