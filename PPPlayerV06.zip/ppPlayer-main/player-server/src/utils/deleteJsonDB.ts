import { db } from "../utils/db";
import dir from "../configPath";

const filePath = dir.mediaPath;
const fs = require("fs");

export default function deleteJsonDb() {
  return new Promise(async function (resolve, reject) {
    try {
      db.delete(`/device`);
      db.delete(`/playlist`);
      fs.rmdirSync(filePath);

      console.log("JsonDB & Folder deleted");
      resolve("JsonDB & Folder deleted");
    } catch (err) {
      console.log("error===>", err);
      reject("Error in JsonDB deleted");
    }
  });
}
