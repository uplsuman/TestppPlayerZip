// const fs = require('fs')
import fs from 'fs'
// import axios from "axios";
// import AWS from "aws-sdk";
const request = require('request')


// const bucketName = "wallview-dev";          // TODO: Need to move to .env

// AWS.config.update({
//     accessKeyId: process.env.AWS_SES_ACCESS_KEY_ID,
//     secretAccessKey: process.env.AWS_SES_SECRET_ACCESS_KEY,
//     region: process.env.AWS_SES_REGION,
// });

// var s3 = new AWS.S3();

export function downloadMedia(url: string, path: any, callback: any) {
    request.head(url, (err: any, res: any, body: any) => {
        request(url)
            .pipe(fs.createWriteStream(path))
            .on('close', callback)
    })
}

    // let data = await axios.get(url)
    // if (data) {
    //     await fs.writeFileSync(path, data.data.result)
    // }
    // return new Promise(function (resolve, reject) {

    //     const params = {
    //         Bucket: process.env.BUCKET || bucketName,
    //         Key: key,
    //     };
    //     try {
    //         s3.getObject(params, async (err, data: any) => {
    //             console.log("data===>", data);

    //             if (data) {
    //                 await fs.writeFileSync(path, data.body)

    //                 console.log(`✅ ${key} download Done!`);
    //             }
    //         })

    //         resolve("key downloaded");

    //     }
    //     catch (error) {
    //         console.log("Error While downloading", error);
    //         reject("Device not downloaded");
    //     }
    // })
// }