import config from "./config";


let io: any


export default {
    init: (server: any) => {
        io = server.listen(config.socketPort);
        io.origins('*:*');
        io.on("connection", async (socket: any) => {
            const deviceId = socket.request._query["deviceId"];

            console.log(deviceId, "Device Connected.");

            if (deviceId) {
                try {
                    socket.join(deviceId);
                } catch (err) {
                    console.log("Error: " + err);
                }
            }
            socket.on("disconnect", () => {
                console.log("Disconnected..!");
            });
        });
        return io;
    },

    get: () => {
        if (!io) {
            throw new Error("socket is not initialized");
        }
        return io;
    }
};