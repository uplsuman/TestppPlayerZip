/**
 * Required External Modules
 */

import * as dotenv from "dotenv";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import config from "./config/index";
import connectToDb from "./database/index";
import routes from "./routes/index";
import { logger } from "shared/src/logger";
import NatsPlugin from "shared/src/natsServices";
import {
  checkDeleteFromPortal,
  checkPortalRegistration,
} from "./utils/deviceService";
import { createPlaylist, updateDevicePlaylist } from "./utils/playlistService";
import http from 'http'
import socketIO from "socket.io";
import socketPort from "./io";

dotenv.config();
const nats = new NatsPlugin(config.natsUrl);

/**
 * App Variables
 */

const app = express();
const socketServer = new http.Server(app);

const socket = socketIO(socketServer, {
  transports: ['websocket', 'polling'],
  allowUpgrades: true
});
const whitelist = ["http://localhost:3000", "http://localhost:3300"];

app.use(helmet());
app.use(cors({ origin: whitelist, credentials: true }));
app.use(express.json());
app.use("/api", routes);


// Connection to mongoDB
// connectToDb();

nats.subscribe("playerservice", (m: any) => {
  console.log("indexmessage===>", m);
  let message = JSON.parse(m);
  switch (message.type) {
    case "DEVICE_CREATE":
      checkPortalRegistration(message, io);
      break;
    case "DEVICE_DELETE":
      checkDeleteFromPortal(message, io);
      break;
    case "PLAYLIST_PUBLISH":
      createPlaylist(message, io);
      break;
    case "PLAYLIST_UPDATE":
      updateDevicePlaylist(message);
      break;
    default:
      console.log("default case!");
  }
});
// Setup Swagger.

const server = socketServer.listen(config.port, () => {
  logger.info(`Server listening on port: http://localhost:${config.port}`);
});

// const io = socket.listen(config.socketPort);

const io = socketPort.init(socket);

// io.on("connection", async (socket: any) => {
//   const deviceId = socket.request._query["deviceId"];

//   console.log(deviceId, "Device Connected.");

//   if (deviceId) {
//     try {
//       socket.join(deviceId);
//     } catch (err) {
//       console.log("Error: " + err);
//     }
//   }
//   socket.on("disconnect", () => {
//     console.log("Disconnected..!");
//   });
// });
