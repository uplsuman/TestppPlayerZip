import express from "express";
import connectionService from "../connectionService";
import devices from "../devices";
import playlist from "../playlist";

let router = express.Router();

router.use("/connection", connectionService);
router.use("/devices", devices);
router.use("/playlists", playlist);

export default router;

