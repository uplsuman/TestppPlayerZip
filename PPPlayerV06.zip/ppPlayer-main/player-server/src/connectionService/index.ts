
import * as express from "express";
import NatsPlugin from "shared/src/natsServices";
import config from "../config/index";
// import exec from 'child_process';
import { promisify } from 'util';
const exec = require("child_process");
const checkInternetConnected = require('check-internet-connected');
const execPromise = promisify(exec.exec)

const router = express.Router();
const nats = new NatsPlugin(config.natsUrl);

const connectivityConfig = {
    timeout: 5000, //timeout connecting to each server(A and AAAA), each try (default 5000)
    retries: 5, //number of retries to do before failing (default 5)
    domain: "google.com", //the domain to check DNS record of
};


/**
 * @type - GET
 * @route -  /api/stripes/prices
 * @desc - route for prices.
 * @access - PUBLIC
 * @function - priceList
 */

router.delete("/splash", async (req, res) => {
    try {
        exec.execSync('sudo systemctl stop wv-splash.service')
        return res.status(200).send({
            error: false,
            message: "Splash Screen Terminated",
        });
    }
    catch (err) {
        return res.status(500).send({
            error: true,
            message: "Internal server error",
        });
    }

});


router.delete("/network", (req, res) => {
    try {
        exec.execSync('sudo systemctl stop wv-checknetwork.service')
        return res.status(200).send({
            error: false,
            message: "Network information",
        });
    }
    catch (err) {
        return res.status(500).send({
            error: true,
            message: "Internal server error",
        });
    }
});



// Shares device WiFi AP Name
router.get("/wifiapname", async (req, res) => {
    try {
        const serial = await execPromise("cat /proc/cpuinfo | grep Serial | cut -d ' ' -f 2")
        const onlySerial = serial.stdout.trim();
        const wifiAPName = `Pictplay-${onlySerial.substr(onlySerial.length - 4)}`;
        return res.status(200).send({
            error: false,
            result: wifiAPName,
            message: "Wifi AP name found"
        });
    }
    catch (err) {
        return res.status(500).send({
            error: true,
            message: "Internal server error",
        });
    }
});


router.get("/reboot", (req, res) => {
    exec("sudo init 6");
});

router.get("/isconnected", async (req, res) => {
    try {
        await checkInternetConnected(connectivityConfig)
        return res.status(200).send({
            error: false,
            message: "Device is connected to netwrok",
        });
    }
    catch (err) {
        return res.status(500).send({
            error: true,
            errorObject: err,
            message: "Device is facing issue with network connectivity",
        });
    }
});

router.get("/wifi", async (req, res) => {
    try {
        const result = await execPromise("iwgetid --raw")
        if (result.stdout.length > 0) {
            res.send({
                error: false,
                message:`Device is connected to ${result.stdout}`,
            })
        }
        else {
            res.send({
                error: true,
                message: "Device is not connected to any network",
            })
        }
    }
    catch (err) {
        console.log(err)
        res.send({
            error: true,
            message: "Device is not connected to any network",
        })
    }
})
export default router;
