const mongoose = require("mongoose");
import logger from "loglevel"
import config from "../config";

logger.setLevel("INFO");
require("dotenv").config();

// logger.level = "error";
export default () => {
  mongoose
    .connect(config.databaseURL, {
      useUnifiedTopology: true,
      useNewUrlParser: true,
      useCreateIndex: true,
    })
    .then(() => logger.info("👉🏾👉🏾 Connected to mongoDb"))
    .catch((err: Error) => {
      logger.error(`Error on connecting to mongo${err}`);
      setTimeout(() => {
        process.exit(1);
      }, 2000);
    });
};
