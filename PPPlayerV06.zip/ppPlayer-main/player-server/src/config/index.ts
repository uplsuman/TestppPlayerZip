import dotenv from "dotenv";
import { logger } from "shared/src/logger";

const envFound = dotenv.config();

if (envFound.error) {
  // This error should crash whole process
  logger.error("⚠️  Couldn't find .env file  ⚠️");
  setTimeout(() => {
    process.exit(1);
  }, 2000);
}

const PORT: number = parseInt(process.env.PORT as string, 10);
const MONGODB_URI: string = process.env.MONGODB_URI as string;
const ENVIRONMENT: string = process.env.NODE_ENV as string;
const NATS: string = process.env.NATS_URL as string;
const MEDIAURL: string = process.env.MEDIA_URL as string;
const SOCKET_PORT: number = parseInt(process.env.socketPort as string, 10);


export default {
  port: PORT,

  databaseURL: MONGODB_URI,

  environment: ENVIRONMENT,

  natsUrl: NATS,

  mediaUrl: MEDIAURL,

  socketPort: SOCKET_PORT,

  api: {
    prefix: "/api",
  },
};

