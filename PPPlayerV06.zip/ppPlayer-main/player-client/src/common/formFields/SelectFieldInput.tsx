import React from "react";
import { withStyles } from "@material-ui/core/styles";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import InputBase from "@material-ui/core/InputBase";
import NativeSelect from "@material-ui/core/NativeSelect";
import PropTypes from "prop-types";

const BootstrapInput = withStyles((theme) => ({
    // root: {
    //   "label + &": {
    //     marginTop: theme.spacing(3),
    //   },
    // },
    input: {
        borderRadius: 4,
        position: "relative",
        backgroundColor: "#fcfcfc",
        border: "1px solid #ced4da",
        fontSize: 16,
        padding: "17px 26px 17px 12px",
        transition: theme.transitions.create(["border-color", "box-shadow"]),
        // Use the system font instead of the default Roboto font.
        fontFamily: [
            "-apple-system",
            "BlinkMacSystemFont",
            '"Segoe UI"',
            "Roboto",
            '"Helvetica Neue"',
            "Arial",
            "sans-serif",
            '"Apple Color Emoji"',
            '"Segoe UI Emoji"',
            '"Segoe UI Symbol"',
        ].join(","),
        "&:focus": {
            borderRadius: 4,
            borderColor: " #80bdff",
            boxShadow: "0 0 0 0.2rem  rgba(0,123,255,.25)",
        },
    },
}))(InputBase);

// const useStyles = makeStyles((theme) => ({
//   //   formControl: {
//   //     margin: theme.spacing(1),
//   //     minWidth: 120,
//   //   },
//   selectEmpty: {
//     marginTop: theme.spacing(2),
//   },
// }));

export default function SelectInputField(props: any) {
    // const classes = useStyles();
    const [state, setState] = React.useState({
        age: "",
        name: "hai",
    });

    const handleChange = (event: any) => {
        const name = event.target.name;
        setState({
            ...state,
            [name]: event.target.value,
        });
        props.onChange(event.target.name, event.target.value);
    };

    return (
        <div className={`textfieldinput ${props.extracls}`}>
            <FormControl
                fullWidth
                className={
                    "selectfieldclass" +
                    " " +
                    (props.textnewclass ? props.textnewclass : "")
                }>
                {/* <FormHelperText id='outlined-weight-helper-text'>
					{props.label}
				</FormHelperText> */}
                <NativeSelect
                    id='demo-customized-select-native'
                    value={props.value}
                    onChange={handleChange}
                    name={props.name}
                    error={props.error}
                    input={<BootstrapInput />}>
                    {props.selectOptions &&
                        props.selectOptions.length > 0 &&
                        props.selectOptions.map((item: any) => {
                            return (
                                <option value={item.value}>
                                    {item.label}{" "}
                                    {item.menu ? "(" + item.menu + ")" : null}
                                </option>
                            );
                        })}
                </NativeSelect>
            </FormControl>
            {props.errorText ? (
                <FormHelperText id='component-error-text' className='errormsg'>
                    {props.errorText}
                </FormHelperText>
            ) : null}
        </div>
    );
}

SelectInputField.prototype = {
    textnewclass: PropTypes.string,
    label: PropTypes.string,
    value: PropTypes.string,
    selectOptions: PropTypes.string,
};