import { Button } from "@material-ui/core"

const CustomButton = () => {
    return (
        <Button variant="contained"></Button>
    )
}

export default CustomButton;