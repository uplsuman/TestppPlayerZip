import rootReducer from "../redux/rootReducer";

export type RootState = ReturnType<typeof rootReducer>


export type mapObject = {
    [key: string]: string | number | boolean | undefined | mapObject | any
}