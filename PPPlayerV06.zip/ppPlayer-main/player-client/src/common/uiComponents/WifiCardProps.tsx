export interface WifiCardProps {
    wifiImgSrc: string;
    wifiName: string;
    lockSrc: string;
    openClicked: any;
}