import './uiComponent.css';
import { Button } from '@material-ui/core';
import text from '../en_US.json'
import PropTypes from "prop-types";

const ConnectScreen = (props:any) => {
    return (
        <div className="connectScreen_main">
            <img alt="logo" src={props.imgSrc} className="connectScreen_main_icon" />
            <h1 className="connectScreen_main_description_h1">{props.pageDescription}</h1>
            {props.showLoader ? <div className="connectScreen_main_loader"><p className="loader"><span>.</span><span>.</span><span>.</span><span>.</span><span>.</span></p></div> : null}
            {props.showButton ? <div className="connectScreen_main_DivButton">
                <p>{text.wificonfigurationSubhead}</p>
                <Button className="connectScreen_main_button" onClick={props.rebootCalled}>{props.buttonText}</Button>
            </div> : null}
        </div>
    )
}

ConnectScreen.prototype={
    imgSrc: PropTypes.string,
    pageDescription: PropTypes.string,
    showLoader: PropTypes.bool,
    showButton: PropTypes.bool,
    buttonText: PropTypes.string,
    rebootCalled: PropTypes.func
}

export default ConnectScreen;