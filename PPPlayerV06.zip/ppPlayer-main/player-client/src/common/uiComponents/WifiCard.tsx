import './wifiCard.css';
import PropTypes from "prop-types";

const WifiCard = (props: any) => {

    return (
        <>
            <div className="wifiCard_main" onClick={props.openClicked}>
                <img alt="" src={props.wifiImgSrc} className="wifiCard_main_img" />
                <p className="wifiCard_main_wifiName">{props.wifiName}</p>
                <img alt="" src={props.lockSrc} className="wifiCard_main_lock" />
            </div>
        </>
    )
}

WifiCard.prototype = {
    wifiImgSrc: PropTypes.string,
    wifiName: PropTypes.string,
    lockSrc: PropTypes.string,
    openClicked: PropTypes.func,
}

export default WifiCard;