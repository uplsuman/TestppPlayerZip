import ROUTES, { RenderRoutes } from "./routes/Index";
// import Index from './container/playerScreens/Index';
// import Media from './container/playerScreens/Media';
import './App.css';
// import Index from "./container/networkScreens/availableNetworks/Index";

function App() {
  return (
    <RenderRoutes routes={ROUTES} />
    // <Index />
    // <Media/>
  )
}

export default App;
