
import { useEffect } from "react";
import { useHistory } from "react-router-dom";

export const UseForPlay = () => {
    // const history = useHistory()

    // useEffect(() => {
    //     setTimeout(() => {
    //         history.push({
    //             pathname: '/noContent',
    //         });
    //     }, 7000);
    // }, [])

    return {
        
    };
};
