// Player screen code goes here
import React, { useState } from "react";
import { useEffect } from "react";
import logo from "../../Images/PictPlay_logo.png";
import { UseForPlay } from "./hook";
import "./Index.css";
import { useHistory, useLocation } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "../../common/interfaces";
import { logger } from "../../logger";
import io from "socket.io-client";
import { getContentList } from "../../redux/action";
let socket: any = null;

const Index = () => {
  const deviceData = useSelector((state: RootState) => state.deviceData);
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();
  const [username, setUsername] = useState("");
  const [socketData, setSocketData] = useState("");

  useEffect(() => {
    if (location.state) {
      let data: any = location.state;
      setSocketData(data.username);
      if (data?.deviceId) {
        connectToSocket(data.deviceId);
      }
    }
  }, [deviceData, location]);

  //socket connection
  const connectToSocket = (deviceId: string) => {
    logger.info("deviceId", deviceId);
    if (deviceId) {
      socket = io.connect(process.env.REACT_APP_SOCKET_URL, {
        reconnection: true,
        query: { deviceId: deviceId },
      });

      socket.on("publish", (data: any) => {
        if (data.result === "PUBLISHED") {
          dispatch(getContentList(history,deviceId));
          history.push({ pathname: "/player" });
        }
      });

      return function cleanup() {
        if (socket !== null) {
          socket.disconnect();
        }
      };
    }
  };

  return (
    <div className="main">
      <img src={logo} alt="logo" className="div_logo" />
      <h2 className="div_h1">Hello, {socketData}</h2>
      <p className="div_p">
        Your device is now successfully <br /> registered to pictplay
      </p>
    </div>
  );
};
export default Index;
