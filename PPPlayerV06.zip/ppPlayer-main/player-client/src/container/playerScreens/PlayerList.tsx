import React from 'react';
import './playerList.css';
import img01 from '../../Images/img01.png';
import img02 from '../../Images/img02.png';
import img03 from '../../Images/img03.png';
import img04 from '../../Images/img04.png';
import img05 from '../../Images/img05.png';
import img06 from '../../Images/img06.png';

const PlayerList = () => {
    return (
        <div className="interfaceMain">
            <div className="mainContainer">
                <div className="seaView">
                    <h4 className="SeaView_h4">Sea-view</h4>
                    <span className="seaView_descrp">owned by me</span>
                    <p className="seaView_p">Unbelievable scenic beautyof sea-view...</p>
                    <span className="seaView_num">3/5 items</span>
                </div>
                <div className="list_parent">
                    <div className="row">
                        <div className="list_img">
                            <img className="Image" alt="img01" src={img01} />
                        </div>
                        <div className="list_text">
                            <h4 className="imageText_h4">Portrait image</h4>
                            <p className="imageText_p">My photography album image</p>
                        </div>
                    </div>
                    <div className="row">
                        <div className="list_img">
                            <img className="Image" alt="img02" src={img02} />
                        </div>
                        <div className="list_text">
                            <h4 className="imageText_h4">Profile image</h4>
                            <p className="imageText_p">Support for unlimited annotations with utmost controland settings.</p>
                        </div>
                    </div>
                    <div className="row">
                        <div className="list_img">
                            <img className="Image" alt="img03" src={img03} />
                        </div>
                        <div className="list_text">
                            <h4 className="imageText_h4">Sea-scape with waves</h4>
                            <p className="imageText_p">Support for unlimited annotations with utmost controland settings.</p>
                        </div>
                    </div>
                    <div className="row">
                        <div className="list_img">
                            <img className="Image" alt="img04" src={img04} />
                        </div>
                        <div className="list_text">
                            <h4 className="imageText_h4">Friends and family together</h4>
                            <p className="imageText_p">Support for unlimited annotations with utmost controland settings.</p>
                        </div>
                    </div>
                    <div className="row">
                        <div className="list_img">
                            <img className="Image" alt="img05" src={img05} />
                        </div>
                        <div className="list_text">
                            <h4 className="imageText_h4">Nature paves the path to peace</h4>
                            <p className="imageText_p">Support for unlimited annotations with utmost controland settings.</p>
                        </div>
                    </div>

                    <div className="myAlbum">
                        <h4 className="myAlbum_h4">My album</h4>
                        <span className="myAlbum_descrp">owned by Emily Lawrence</span>
                        <p className="myAlbum_p">Unbelievable scenic beautyof sea-view...</p>
                        <span className="myAlbum_num">3/5 items</span>
                    </div>
                    <div className="row">
                        <div className="list_img">
                            <img className="Image" alt="img06" src={img06} />
                        </div>
                        <div className="list_text">
                            <h4 className="imageText_h4">Devine beauty of colour</h4>
                            <p className="imageText_p">Support for unlimited annotations with utmost controland settings.</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    )
}

export default PlayerList;