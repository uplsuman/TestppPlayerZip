import ConnectScreen from "../../common/uiComponents/ConnectScreen";
import React, { useEffect, useState } from "react";
import logo from "../../Images/PictPlay_logo.png";
import "./Index.css";
import text from "../../common/en_US.json";
import { UseForPlay } from "./hook";
import { logger } from "../../logger";
import { useSelector } from "react-redux";
import { RootState } from "../../common/interfaces";
import { useDispatch } from "react-redux";
import { contentList, getContentList } from "../../redux/action";
import io from "socket.io-client";
import { useHistory, useLocation } from "react-router-dom";

let socket: any = null;

const NoContent = () => {
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();
  const deviceData = useSelector((state: RootState) => state.deviceData);
  useEffect(() => {
    logger.info(deviceData, "deviceData");
    if (deviceData?.deviceId) {
      connectToSocket(deviceData?.deviceId);
    }
  }, [deviceData]);

  const connectToSocket = (deviceId: string) => {
    logger.info("deviceId", deviceId);
    if (deviceId) {
      socket = io.connect(process.env.REACT_APP_SOCKET_URL, {
        reconnection: true,
        query: { deviceId: deviceId },
      });

      socket.on("publish", (data: any) => {
        if (data.result === "PUBLISHED") {
          dispatch(getContentList(history, deviceId));
          history.push({ pathname: "/player" });
        }
        else if (data?.result?.type === "DOWNLOAD" && window?.location?.pathname?.match('/noContent')) {
          console.log('nocontent')
          // let arr: any = []
          // arr.push(data?.result?.key)
          // dispatch(contentList(arr));
          history.push({ pathname: "/player" });
        }
      });

      return function cleanup() {
        if (socket !== null) {
          socket.disconnect();
        }
      };
    }
  };
  return (
    <div className="noContentScreen">
      <ConnectScreen
        imgSrc={logo}
        pageDescription={text.NoContentTxt}
        showLoader={false}
        showButton={false}
        buttonText=""
      />
    </div>
  );
};
export default NoContent;
