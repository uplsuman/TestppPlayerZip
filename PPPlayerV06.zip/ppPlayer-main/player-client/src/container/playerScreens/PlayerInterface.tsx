import React, { useEffect, useState } from "react";
import Media from "./Media";
import "./playerInterface.css";
import PlayerList from "./PlayerList";
import pause from "../../Images/pause.png";
import backgroundImg from "../../Images/background.jpg";
import Loading from "../../Images/Loading.png";
import { useSelector } from "react-redux";
import { RootState } from "../../common/interfaces";
import Index from "../playlist/media/mediaPlayer/Index";
import io from "socket.io-client";
import { logger } from "../../logger";
import { useHistory, useLocation } from "react-router-dom";
import { useDispatch } from "react-redux";
import { contentList, getContentList } from "../../redux/action";
import logo from '../../Images/PictPlay_logo.png';


let socket: any = null;

const PlayerInterface = () => {
  const history = useHistory();
  const location: any = useLocation();
  const dispatch = useDispatch();

  const contents = useSelector((state: RootState) => state.contentList);
  const deviceData = useSelector((state: RootState) => state.deviceData);
  const [showLoading, setShowLoading] = useState(false);
  const [contentData, setContentData] = useState([]);

  useEffect(() => {
    if (contents.length > 0) {
      // if (contents === 'DOWNLOADING') {
      //   logger.info("content downloading");
      //   setShowLoading(true);
      // }
      // else {
      console.log("got content list");
      setContentData(contents);
      setShowLoading(false);
      // }
    }
    else {
      setShowLoading(true);
      dispatch(getContentList(history, deviceData?.deviceId))
      logger.info("From player interface fetch content");
    }
  }, [contents, deviceData]);

  useEffect(() => {
    logger.info(deviceData, "deviceData");
    if (deviceData?.deviceId) {
      connectToSocket(deviceData?.deviceId);
    }
  }, [deviceData]);

  const connectToSocket = (deviceId: string) => {
    logger.info("deviceId", deviceId);
    if (deviceId) {
      socket = io.connect(process.env.REACT_APP_SOCKET_URL, {
        reconnection: true,
        query: { deviceId: deviceId },
      });

      socket.on("publish", (data: any) => {
        if (data.result === "PUBLISHED") {
          dispatch(contentList([]))
          setShowLoading(true);
        }
        else if (data.result === "DEVICE_DELETE") {
          history.push({ pathname: '/' })
        }
        else if (data?.result?.type === "DOWNLOAD") {
          // let arr: any = [...contentData];
          contents.push(data?.result?.key)
          dispatch(contentList(contents))
          // setContentData(arr);
          setShowLoading(false);
        }
      });

      return function cleanup() {
        if (socket !== null) {
          socket.disconnect();
        }
      };
    }
  };


  return (
    <div className="playerInterface_main">
      <div className="playerInterface_main_imgDiv">
        {/* <img className="playerInterface_main_img" alt="" src={backgroundImg} /> */}
        <Index contentList={contentData} />
      </div>
      {/* <PlayerList /> */}
      {/* <Media contentList={contentList}/> */}
      {showLoading &&
        <div className="playerInterface_main_pause_section">
          <img className="pause_section_img" alt="pause" src={logo} />
          <h3 className="pause_section_h3">Loading...</h3>
        </div>}
      {/* <div className="playerInterface_main_pause_section">
        <img className="pause_section_img" alt="pause" src={pause} />
        <h3 className="pause_section_h3">Paused</h3>
      </div> */}

      {/* <div className="upload_sec">
                <img className="upload_img" alt="loading" src={Loading} />
                <p className="upload_p">Uploading playlist01 40% completed</p>
            </div> */}
    </div>
  );
};

export default PlayerInterface;
