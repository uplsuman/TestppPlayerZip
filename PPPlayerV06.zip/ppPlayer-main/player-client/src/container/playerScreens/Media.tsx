// Player screen code goes here

import React, { useEffect } from 'react';
import './Media.css';



const Media = (props: any) => {


    return (
        <div className="interfaceMain">
            <div className="mainContainer">
                <div className="seaView">
                    <h4 className="SeaView_h4">Sea-view</h4>
                    <p className="seaView_p">Unbelievable scenic beautyof sea-view...</p>
                    <span className="seaView_num">3/5 items</span>
                </div>
                <div className="list_parent">
                    {props.contentList.map((x: any, idx: number) => {
                        return (
                            <div className="row">
                                <img className="image" alt="Album01"
                                    src={`media/${x}`}
                                />
                            </div>
                        )
                    })
                    }
                </div>

            </div>
        </div>
    )
}

export default Media;