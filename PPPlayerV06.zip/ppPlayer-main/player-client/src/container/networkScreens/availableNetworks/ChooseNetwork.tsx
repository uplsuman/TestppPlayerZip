import './chooseNetwork.css';
import { PropsData } from './PropsData';
const ChooseNetwork = ({ imgSrc, pageDescription }: PropsData) => {
    return (
        <div className="chooseNetwork_main">
            <img alt="logo" src={imgSrc} className="chooseNetwork_main_icon" />
            <h1 className="chooseNetwork_main_description_h1">{pageDescription}</h1>
        </div>
    )
}

export default ChooseNetwork;