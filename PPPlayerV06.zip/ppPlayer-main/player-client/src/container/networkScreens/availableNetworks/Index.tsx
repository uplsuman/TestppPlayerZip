import './Index.css';
import wifiImg from '../../../Images/wifiImg1.png';
// import ConnectScreen from '../../../common/uiComponents/ConnectScreen';
import wifi from '../../../Images/wifi1.png';
import text from '../../../common/en_US.json'
import WifiCard from '../../../common/uiComponents/WifiCard';
import lockImg from '../../../Images/lock-small.png';
import lineImg from '../../../Images/LineImg.png';
// import crossImg from '../../../Images/crossImg.png';
import ChooseNetwork from './ChooseNetwork';
import { UseForAvailableNetwork } from './hook';
import ConnectToNetwork from './ConnectToNetwork';
import { Divider, Drawer } from '@material-ui/core';
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';
import arrowImg from '../../../Images/arrow-left.png';
// import ConnectToNetwork from './ConnectToNetwork';
// import { useState } from 'react';

const drawerWidth = 400;

const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            display: 'flex',
        },
        appBar: {
            transition: theme.transitions.create(['margin', 'width'], {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.leavingScreen,
            }),
        },
        appBarShift: {
            width: `calc(100% - ${drawerWidth}px)`,
            marginLeft: drawerWidth,
            transition: theme.transitions.create(['margin', 'width'], {
                easing: theme.transitions.easing.easeOut,
                duration: theme.transitions.duration.enteringScreen,
            }),
        },
        menuButton: {
            marginRight: theme.spacing(2),
        },
        hide: {
            display: 'none',
        },
        drawer: {
            width: '100%',
            flexShrink: 0,
            backgroundColor: '#111213',

        },
        drawerPaper: {
            width: 'fit-content',
        },
        drawerHeader: {
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            padding: theme.spacing(0, 1),
            ...theme.mixins.toolbar,
            justifyContent: 'flex-start',
        },
    }),
);

const Index = () => {
    const { open, openClicked, goToNext, handleDrawerClose } = UseForAvailableNetwork()
    const classes = useStyles();

    return (<>
        <div className="availableNetwork_main">
            <div className="availableNetwork_main_left">
                <div className="availableNetwork_main_left_section">
                    <h1 className="availableNetwork_main_left_h1">{text.chooseAvailableNetworkText}</h1>
                </div>
                <div className="availableNetwork_main_left_box">
                    <p className="availableNetwork_main_left_box_p1">{text.availableNetworks}</p>
                </div>
                <img alt="line" src={lineImg} className="availableNetwork_main_lineImg" />
                <div className="availableNetwork_wifiIcon_list">
                    <WifiCard wifiImgSrc={wifiImg} wifiName="Galaxy M12" lockSrc={lockImg} openClicked={openClicked} />
                    <WifiCard wifiImgSrc={wifiImg} wifiName="Mynetwork_123" lockSrc={lockImg} openClicked={openClicked} />
                    <WifiCard wifiImgSrc={wifiImg} wifiName="Home_network_02" lockSrc={lockImg} openClicked={openClicked} />
                    <WifiCard wifiImgSrc={wifiImg} wifiName="Galaxy A315432" lockSrc={lockImg} openClicked={openClicked} />
                    <WifiCard wifiImgSrc={wifiImg} wifiName="Office_network_01" lockSrc={lockImg} openClicked={openClicked} />
                    <WifiCard wifiImgSrc={wifiImg} wifiName="Galaxy A7102" lockSrc={lockImg} openClicked={openClicked} />
                </div>
            </div>
            <div className="availableNetwork_main_right">
                {open === true ?
                    <ConnectToNetwork goToNext={goToNext}/>
                    :
                    <ChooseNetwork imgSrc={wifi} pageDescription={text.chooseFromText} />}
            </div>
            <div className="drawer_wraper">
                <Drawer className={classes.drawer} variant="persistent" anchor="right" open={open}
                    classes={{
                        paper: classes.drawerPaper,
                    }}>

                    <div className={classes.drawerHeader}>
                        <div className="drawer_header">
                            <img className="drawer_header_img" src={arrowImg} alt="arrow-left" onClick={handleDrawerClose} />
                            <p className="drawer_haeder_p">Please enter password</p>
                        </div>
                    </div>
                    <Divider />
                    <ConnectToNetwork />
                </Drawer>
            </div>
        </div>
    </>)
}

export default Index;