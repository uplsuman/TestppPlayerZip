export interface PropsData {
    imgSrc: string;
    pageDescription: string;
}