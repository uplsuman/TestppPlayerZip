import { Button, IconButton, InputAdornment, TextField } from '@material-ui/core';
import './connectToNetwork.css';
import countries from '../../../common/country.json';
import { useState } from 'react';
import VisibilityOffIcon from '@material-ui/icons/VisibilityOff';
import SelectInputField from '../../../common/formFields/SelectFieldInput';
import VisibilityIcon from '@material-ui/icons/Visibility';

const ConnectToNetwork = (props:any) => {

    const [selectedCountry, setSelectedCountry] = useState(0)

    const [pass, setPass] = useState();
    console.log(pass);

    const handleChange = (event: any) => {
        setPass(event.target.value);
    };
    const [showPassword, setShowPassword] = useState(false);

    const selectCountry = (name: any, value: any) => {
        setSelectedCountry(value);
    };

    const countryOption = countries.map((state) => {
        return { label: state.name, value: state.code };
    })

    const handleClickShowPassword = () => {
        setShowPassword(!showPassword);
    };


    return (
        <div className="connectToNetwork_main">
            <form className="connectToNetwork_main_form">
                <div className="connectToNetwork_main_form_divLabel">
                    <label className="connectToNetwork_main_form_label">Enter Password</label>
                    <p className="connectToNetwork_main_form_divLabel_p">Connect</p>
                </div>

                <div className="connectToNetwork_select">
                    <SelectInputField
                        extracls="selectInput"
                        selectOptions={countryOption}
                        onChange={selectCountry}
                        value={selectedCountry}
                    />
                </div>

                <div className="connectToNetwork_select">
                    <TextField id="outlined-start-adornment" placeholder="Password" variant="outlined" type={showPassword ? 'text' : 'password'}
                        onChange={handleChange}
                        InputProps={{
                            endAdornment: <InputAdornment position="end">
                                <IconButton
                                    aria-label="toggle password visibility"
                                    onClick={handleClickShowPassword}
                                    edge="end"
                                >
                                    {showPassword ? <VisibilityIcon style={{ color: '#C4C4C4' }} /> : <VisibilityOffIcon style={{ color: '#C4C4C4' }} />}
                                </IconButton>
                            </InputAdornment>,
                        }} fullWidth />
                </div>

                <div className="connectToNetwork_main_DivButton">
                    <Button className="connectToNetwork_main_button" onClick={props.goToNext}>Connect</Button>
                </div>

            </form>
        </div>
    )
}

export default ConnectToNetwork;