
import { useState } from "react";
import { useHistory } from "react-router-dom";

export const UseForAvailableNetwork = () => {
    const [open, setOpen] = useState(false)
    const history = useHistory()
    const openClicked = () => {
        setOpen(true)
    }
    const handleDrawerClose = () => {
        setOpen(false)
    }
    const goToNext = () => {
        history.push({
            pathname: '/',
            state: 'availableNet'
        });
    }
    return {
        openClicked,
        open,
        goToNext,
        handleDrawerClose
    };
};
