import wifiImg from '../../Images/wifiImg.png';
import lockImg from '../../Images/lockImg.png';
import linkImg from '../../Images/linkImg.png';
import loginImg from '../../Images/loginImg.png';
import scanQRImg from '../../Images/scanQRImg.png';
import qrImg from '../../Images/QRImg.png';
import lineImg from '../../Images/LineImg.png';
import './Index.css';
import '../connectingScreens/pictPlayConnection/Index'
import text from '../../common/en_US.json';
import { UseForWifi } from './hook';

const Index = () => {
    const { goToNext } = UseForWifi()
    return (<>
        <div className="pictplayConnection_main">
            <div className="pictplayConnection_main_div_left">
                <div className="pictplayConnection_head">
                    <h1 className="pictplayConnection_head_h1">{text.connectToNetwork}</h1>
                    <p className="pictplayConnection_head_p">{text.toContinueText}</p>
                    <img alt="Line" src={lineImg} className="pictplayConnection_head_line" />
                </div>
                <h3 className="pictplayConnection_h3">{text.vistWebsite}</h3>
                <div className="pictplayConnection_list">
                    <div className="pictplayConnection_listImg">
                        <img alt="wifi" src={wifiImg} className="pictplayConnection_list_img" />
                        <img alt="lock" src={lockImg} className="pictplayConnection_list_img" />
                        <img alt="link" src={linkImg} className="pictplayConnection_list_img" />
                        <img alt="login" src={loginImg} className="pictplayConnection_list_img" />

                    </div>
                    <div className="pictplayConnection_listP">
                        <p className="pictplayConnection_list_p">{text.connectToWifi} <span className="pictplayConnection_list_span">{text.pictPlay}</span></p>
                        <p className="pictplayConnection_list_p">{text.userPasswordText} <span className="pictplayConnection_list_span">{text.pictPlay}</span></p>
                        <p className="pictplayConnection_list_p">{text.onPhoneVisit} <span className="pictplayConnection_list_span">http:/pictplay.local</span></p>
                        <p className="pictplayConnection_list_p end">{text.loginAccessText}</p>
                    </div>
                </div>
                <div className="pictplayConnection_bottom">
                    <img alt="Line" src={lineImg} className="pictplayConnection_head_bottom" />
                    <p className="pictplayConnection_head_p">{text.toSignInText}</p>
                </div>
            </div>
            <div className="pictplayConnection_main_div_right">
                <img alt="QR code" src={scanQRImg} className="pictplayConnection_phone" />
                <div className="pictplayConnection_main_div_right_content" onClick={goToNext}>
                    <img alt="QR code" src={qrImg} className="pictplayConnection_qrCode" />
                </div>
            </div>
        </div>
    </>)
};
export default Index;