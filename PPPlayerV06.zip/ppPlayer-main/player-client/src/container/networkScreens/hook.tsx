
import { useHistory } from "react-router-dom";

export const UseForWifi = () => {
    const history = useHistory()

    const goToNext = () => {
        history.push({
            pathname: '/',
            state: 'fromConnect'
        });
    }

    return {
        goToNext
    };
};
