// import logo from "./logo.svg";
import React, { useState, useEffect, useRef } from "react";
import "./Index.css";
// import playIcon from "./images/play-fill.png";
// import pauseIcon from "./images/pause.png";
// import volumeIcon from "./images/volume-up-fill.png";
// import fullScreen from "./images/fullscreen.png";
// import more from "./images/more.png";
// import ProgressBar from "./ProgressBar";
import ReactPlayer from "react-player";
import { MATCH_URL_IMAGE } from "./FilesPatterns";
// import classes from '*.module.css';
import { makeStyles, withStyles } from "@material-ui/core/styles";
import PlayerControls from "./PlayerControls";
// import screenfull from "screenfull";
// import IconButton from "@material-ui/core/IconButton";
// import PlayArrowIcon from "@material-ui/icons/PlayArrow";
// import SkipPreviousIcon from "@material-ui/icons/SkipPrevious";
// import SkipNextIcon from "@material-ui/icons/SkipNext";
// import VolumeUpIcon from "@material-ui/icons/VolumeUp";
// import FullScreenIcon from "@material-ui/icons/Fullscreen";
import Grid from "@material-ui/core/Grid";
// import Typography from "@material-ui/core/Typography";
// import Button from "@material-ui/core/Button";
import Slider from "@material-ui/core/Slider";
import PropTypes from "prop-types";

// custom controls start

const useStyles = makeStyles({
    playerWrapper: {
        width: "100%",
        position: "relative",
        height: "100%",
    },
    bottomIcons: {
        color: "#FFF",
        padding: 0,
        height: 30,
        width: 30,
        "&:hover": {
            color: "#fff",
            padding: 0,
        },
    },
});

const PrettoSlider = withStyles({
    root: {
        // height: 8,
        color: "#4DD6DB",
        padding: '4px 0'
    },
    active: {
    },
    // valueLabel: {
    //     left: "calc(-50% + 4px)",
    // },
    // track: {
    //     height: 8,
    //     borderRadius: 4,
    //     // backgroundcolor: "#4DD6DB",
    // },
    // rail: {
    //     height: 8,
    //     borderRadius: 4,
    // },
})(Slider);

function PlaylistPlayer(props: any) {

    const classes = useStyles();
    const playerRef = useRef(null);
    const playerContainerRef = useRef(null);
    // const [timeDisplayFormat, setTimeDisplayFormat] = React.useState("normal");
    const [state, setState] = useState({
        playing: true,
        muted: false,
        volume: 0.5,
        played: 0,
        seeking: false,
    });
    const [progressWidth, setProgressWidth] = useState(10)

    //destructure

    const { playing,
        muted,
        volume,
        played,
        seeking
    } = state;

    // const format = (seconds: any) => {
    //     if (isNaN(seconds)) {
    //         return `00:00`;
    //     }
    //     const date = new Date(seconds * 1000);
    //     const hh = date.getUTCHours();
    //     const mm = date.getUTCMinutes();
    //     const ss = date.getUTCSeconds().toString().padStart(2, "0");
    //     if (hh) {
    //         return `${hh}:${mm.toString().padStart(2, "0")}:${ss}`;
    //     }
    //     return `${mm}:${ss}`;
    // };

    //   const currentTime =
    //     playerRef && playerRef.current
    //       ? playerRef.current.getCurrentTime()
    //       : "00:00";

    //   const duration =
    //     playerRef && playerRef.current ? playerRef.current.getDuration() :
    //      "00:00";

    //   const elapsedTime =
    //     timeDisplayFormat == "normal"
    //       ? format(currentTime)
    //       : `-${format(duration - currentTime)}`;

    //const totalDuration = format(duration);

    useEffect(() => {
        let count = parseInt(props.timeCount, 10);
        let totalCount = parseInt(props.totalDuration, 10);
        let progress = count * (100 / totalCount);
        // console.log(count, totalCount, progress, 'totalCount');
        setProgressWidth(progress)
    }, [props.timeCount, props.totalDuration])

    const handlePlayPause = () => {
        setState({ ...state, playing: !state.playing });
    };

    const handleMute = () => {
        setState({ ...state, muted: !state.muted });
    };

    const handleVolumeChange = (e: any, newValue: any) => {
        setState({
            ...state,
            volume: (newValue / 100),
            muted: newValue === 0 ? true : false,
        });
    };

    const handleVolumeSeekUp = (e: any, newValue: any) => {
        setState({
            ...state,
            volume: (newValue / 100),
            muted: newValue === 0 ? true : false,
        });
    };

    // const toggleFullScreen = () => {
    //     //screenfull.toggle(playerContainerRef.current);
    // };

    const handleProgress = (changeState: any) => {
        console.log(changeState);
        if (!state.seeking) {
            setState({ ...state, ...changeState });
        }
    };

    const handleSeekChange = (e: any, newValue: any) => {
        setState({ ...state, played: (newValue / 100) });
    };

    const handleSeekMouseDown = (e: any) => {
        setState({ ...state, seeking: true });
    };

    const handleSeekMouseUp = (e: any, newValue: any) => {
        setState({ ...state, seeking: false });
        //playerRef.current.seekTo(newValue / 100);
    };

    // const handleDisplayFormat = () => {
    //     setTimeDisplayFormat(
    //         timeDisplayFormat == "normal" ? "remaining" : "normal"
    //     );
    // };

    // custom controls end

    // calculating progress of the image
    // let count = parseInt(props.timeCount, 10);
    // let totalCount = parseInt(props.totalDuration, 10);
    // const progressWidth = count * (100 / totalCount);


    return (
        <div className="App">
            <div className="container-slider">
                <div
                    id="myCarousel"
                    className="carousel slide"
                    data-ride="carousel"
                    data-interval="9000"
                    data-pause="false"
                >
                    {/* <!-- Wrapper for carousel items --> */}
                    <div className="carousel-inner">
                        {!props.mediaUrl?.includes('/v/') ?
                            (
                                <div className="item active">
                                    <div className="item-image" style={{ objectFit: "cover" }}>
                                        <img alt="" src={props.mediaUrl} />
                                    </div>
                                    <div className="player-main-cls">
                                        {/* <PrettoSlider
                                            value={props.picSliderValue}
                                            min={0}
                                            max={100}
                                        //defaltValue={100}
                                        /> */}
                                        <Grid
                                        container
                                        direction="row"
                                        justify="space-between"
                                        alignItems="center"
                                    >
                                        <Grid item xs={12} >
                                            {/* <PrettoSlider
                                                min={0}
                                                max={100}
                                            //defaltValue={100}

                                            /> */}
                                            <div className="progress-bar">
                                                <div
                                                    className="loaded"
                                                    style={{
                                                        width: `${progressWidth}%`,
                                                        backgroundColor: "#4DD6DB",
                                                    }}
                                                ></div>
                                            </div>
                                        </Grid>
</Grid>
                                        {/* <Grid
                                            container
                                            direction="row"
                                            justify="space-between"
                                            alignItems="center"
                                            style={{ padding: '0 20px' }}
                                        > */}
                                        {/* <Grid item xs={12} >
                                                <PrettoSlider
                                                    value={props.picSliderValue}
                                                    min={0}
                                                    max={100}
                                                />
                                            </Grid> */}
                                        {/* <Grid item >
                                            <Grid container alignItems="center" direction="row">
                                                <IconButton className={`${classes.bottomIcons} previousbtn`}>
                                                    <SkipPreviousIcon />
                                                </IconButton>
                                                <IconButton className={`${classes.bottomIcons} playbtn`}>
                                                    <PlayArrowIcon />
                                                </IconButton>
                                                <IconButton className={`${classes.bottomIcons} nextbtn`}>
                                                    <SkipNextIcon fontSize="medium" />
                                                </IconButton>
                                                <IconButton className={`${classes.bottomIcons} volumebtn`}>
                                                    <VolumeUpIcon fontSize="medium" />
                                                </IconButton>

                                                <Button
                                                    variant="text"
                                                    style={{ color: "#fff", marginLeft: 16 }}
                                                >
                                                    <Typography>
                                                        2.5s / 10s
                                                    </Typography>
                                                </Button>
                                            </Grid>
                                        </Grid> */}
                                        {/* <Grid item>
                                            <IconButton
                                                className={classes.bottomIcons}
                                            >
                                                <FullScreenIcon fontSize="medium" />
                                            </IconButton>
                                        </Grid> */}
                                        {/* </Grid> */}

                                    </div>
                                </div>

                            ) : (
                                <>
                                    <div className={classes.playerWrapper} ref={playerContainerRef}>
                                        <ReactPlayer
                                            ref={playerRef}
                                            className="PPplayer"
                                            muted={muted}
                                            url={props.mediaUrl}
                                            width="100%"
                                            height="100%"
                                            playing={playing}
                                            //onEnded={props.onEnded}
                                            playsinline={true}
                                            volume={volume}
                                            onProgress={handleProgress}
                                        ></ReactPlayer>


                                        <PlayerControls
                                            onPlayPause={handlePlayPause}
                                            playing={playing}
                                            muted={muted}
                                            onMute={handleMute}
                                            onVolumeChange={handleVolumeChange}
                                            onVolumeSeekUp={handleVolumeSeekUp}
                                            volume={volume}
                                            //onToggleFullScreen={toggleFullScreen}
                                            played={played}
                                            onSeek={handleSeekChange}
                                            onSeekMouseDown={handleSeekMouseDown}
                                            onSeekMouseUp={handleSeekMouseUp}
                                        //elapsedTime={elapsedTime}
                                        //onChangeDispayFormat={handleDisplayFormat}
                                        //totalDuration={totalDuration}
                                        />
                                    </div>
                                </>
                            )
                        }
                        {props.subTitle && props.subTitle.length > 0 && (
                            <div className="carousel-caption d-none d-md-block">
                                <h2>{props.subTitle}</h2>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );

}
PlaylistPlayer.prototype = {
    onPlayPause: PropTypes.func,
    playing: PropTypes.bool,
    muted: PropTypes.bool,
    onMute: PropTypes.func,
    onVolumeChange: PropTypes.func,
    onVolumeSeekUp: PropTypes.func,
    volume: PropTypes.number,
}

export default PlaylistPlayer;
