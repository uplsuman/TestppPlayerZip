import React from 'react'
const ProgressBar = (props: any) => {
    // const { bgcolor, completed } = props;

    const containerStyles = {
        height: 2.5,
        // backgroundColor: "#99969a9e",
        backgroundColor: "#4DD6DB",
        borderRadius: 50,
        // marginTop: 10,
    }

    // const fillerStyles = {
    //     height: '100%',
    //     width: `${completed}%`,
    //     backgroundColor: bgcolor,
    //     borderRadius: 'inherit',
    //     textAlign: 'right',
    //     transition: 'width 1s ease-in-out',
    // }

    // const labelStyles = {
    //     padding: 5,
    //     color: 'white',
    //     fontWeight: 'bold'
    // }

    return (
        <div style={containerStyles}>
            <div
            //style={fillerStyles}
            >
                {/* <span style={labelStyles}>{`${completed}%`}</span> */}
            </div>
        </div>
    );
};

export default ProgressBar;