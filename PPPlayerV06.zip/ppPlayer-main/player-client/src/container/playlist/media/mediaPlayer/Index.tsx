import React, { Component, useEffect, useState, useRef } from "react";
import PlaylistPlayer from "./PlaylistPlayer";
import { MATCH_URL_IMAGE } from "./FilesPatterns";
import Album01 from "../../../../Images/Album01.png";
import Album02 from "../../../../Images/Album02.png";
import Album03 from "../../../../Images/Album03.png";
import Album04 from "../../../../Images/Album04.png";
// import * from  'video-react/dist/video-react.css';

const useFull = (el: any) => {
  const [full, setFull] = useState(false);
  const revert = () => {
    if (!document.fullscreenElement) {
      setFull(false);
      document.removeEventListener("fullscreenchange", revert);
    }
  };
  useEffect(() => {
    if (full) {
      const elem = el.current;
      if (elem.requestFullscreen) {
        elem.requestFullscreen();
        document.addEventListener("fullscreenchange", revert);
      } else if (elem.webkitRequestFullscreen) {
        /* Safari */
        elem.webkitRequestFullscreen();
        document.addEventListener("fullscreenchange", revert);
      } else if (elem.msRequestFullscreen) {
        /* IE11 */
        elem.msRequestFullscreen();
        document.addEventListener("fullscreenchange", revert);
      }
    } else {
      console.log("errir");
    }
    return () => {
      document.removeEventListener("fullscreenchange", revert);
    };
  }, [full]);
  return [full, setFull];
};
function Index(props: any) {
  const picRef = useRef(null); //reference taken for displaying the screen to full
  const [full, setFull] = useFull(picRef); //outside functionality called for full screen switch
  // const [media] = useState(['https://st.depositphotos.com/1428083/2946/i/600/depositphotos_29460297-stock-photo-bird-cage.jpg?subTitle=Subtitle Text Para']) //media state containing only images
  // const [media] = useState(
  //   [Album01, Album02, Album03, Album04,
  //     'https://www.pxwall.com/wp-content/uploads/2018/05/amazing-natural-photo.jpg?duration=4',
  //     'https://www.pxwall.com/wp-content/uploads/2020/05/Lion-HD-Wallpaper-scaled.jpg']) //media containing image and video both
  const [index, setIndex] = useState(0); //state refering to the index of the modeia its playing
  const [timeCount, setTimeCount] = useState(0); //state to display the part of the image done
  const [subTitle, setSubTitle] = useState(""); //state to display the subtitle if there is any
  const [media, setMedia]: any[] = useState([]);
  //global function to search query value from a url by passing the parameter need to find as parameter
  function getQueryStringValue(key: any) {
    return decodeURIComponent(
      media[index]?.replace(
        new RegExp(
          "^(?:.*[&\\?]" +
          encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") +
          "(?:\\=([^&]*))?)?.*$",
          "i"
        ),
        "$1"
      )
    );
  }

  useEffect(() => {
    // console.log('content data', media)
  }, [media]);

  useEffect(() => {
    if (props.contentList) {
      setMedia(props.contentList);
    }
  }, [props.contentList]);

  //invokes to get the value from a url
  useEffect(() => {
    if (media[index]) {
      let title = getQueryStringValue("subTitle");
      // console.log(title);
      setSubTitle(title);
    }
  }, [media, index]);

  const imageDuration: any =
    getQueryStringValue("duration") &&
      Number(getQueryStringValue("duration")) > 0
      ? getQueryStringValue("duration")
      : 10; //state to detect image timing
  // console.log("imageDuration== " + imageDuration);

  //functionality invokes after a video ends
  const onEnded = () => {
    if (index === media.length - 1) {
      setIndex(0);
    } else {
      setIndex(index + 1);
    }
  };

  //invokes when a media is an image
  useEffect(() => {
    if (media[index]?.match(MATCH_URL_IMAGE)) {
      if (index === media.length - 1) {
        setIndex(0);
      } else {
        setTimeout(() => {
          setIndex(index + 1);
        }, imageDuration * 1000);
      }
      setTimeCount(0);
    }
  }, [media, index, imageDuration]);

  //invokes when the full screen functionality called from a image
  const switchToFull = () => {
    //setFull(!full)
    // setFull(false)
  };

  //invokes for image progress bar
  useEffect(() => {
    if (media[index]?.match(MATCH_URL_IMAGE)) {
      const timer = setInterval(() => {
        setTimeCount((prevProgress) =>
          prevProgress >= imageDuration ? 0 : prevProgress + 1
        );
      }, 1000);
      return () => {
        clearInterval(timer);
      };
    }
  }, [imageDuration]);

  return (
    <div className="picture_player_screen" ref={picRef}>
      <div className="picture_player_sec">
        <PlaylistPlayer
          mediaUrl={`${process.env.REACT_APP_serverurl}/playlists/images?key=${media[index]}`}
          picSliderValue={index * 10}
          animationSec={`${imageDuration}s`}
          // onClick={switchToFull}
          timeCount={timeCount < 10 ? `0${timeCount}` : timeCount}
          totalTimeCount={
            imageDuration < 10 ? `0:0${imageDuration}` : `0:${imageDuration}`
          }
          onEnded={onEnded}
          // subTitle={subTitle}
          totalDuration={imageDuration}
        />
      </div>
    </div>
  );
}
export default Index;
