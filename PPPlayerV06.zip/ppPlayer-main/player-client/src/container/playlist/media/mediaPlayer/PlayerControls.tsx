import React from "react";
// import playIcon from "./images/play-fill.png";
// import pauseIcon from "./images/pause.png";
// import volumeIcon from "./images/volume-up-fill.png";
// import fullScreen from "./images/fullscreen.png";
// import more from "./images/more.png";
// import ProgressBar from "./ProgressBar";
// import ReactPlayer from "react-player";
// import { MATCH_URL_IMAGE } from "./patterns";
//import { PlayerIcon, PlaybackControls } from "react-player-controls";
// import classes from '*.module.css';
import { makeStyles, withStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import Slider from "@material-ui/core/Slider";
// import Tooltip from "@material-ui/core/Tooltip";
// import IconButton from "@material-ui/core/IconButton";
// import PlayArrowIcon from "@material-ui/icons/PlayArrow";
// import VolumeUpIcon from "@material-ui/icons/VolumeUp";
// import VolumeOff from "@material-ui/icons/VolumeOff";
// import Button from "@material-ui/core/Button";
// import Typography from "@material-ui/core/Typography";
// import FullScreenIcon from "@material-ui/icons/Fullscreen";
// import previous from "./images/previous.png";
// import next from "./images/next.png";
// import SkipPreviousIcon from "@material-ui/icons/SkipPrevious";
// import SkipNextIcon from "@material-ui/icons/SkipNext";
// import PauseIcon from "@material-ui/icons/Pause";
import './Index.css'
import PropTypes from "prop-types";

const useStyles = makeStyles({
  playerWrapper: {
    width: "100%",
    position: "relative",
    height: "100%",
  },
  controlsWrapper: {
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "transparent",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
    zIndex: 1,
    position: "absolute",
  },
  bottomIcons: {
    color: "#FFF",
    "&:hover": {
      color: "#fff",
    },
  },
  volumeSlider: {
    width: 100,
    color: "#fff!important",
  },
});

// function ValueLabelComponent(props: any) {
//   const { children, open, value } = props;

//   return (
//     <Tooltip open={open} enterTouchDelay={0} placement="top" title={value}>
//       {children}
//     </Tooltip>
//   );
// }

const PrettoSlider = withStyles({
  root: {
    height: 8,
    color: "#4DD6DB",
  },
  // thumb: {
  //   height: 24,
  //   width: 24,
  //   backgroundColor: "#fff",
  //   border: "2px solid currentColor",
  //   marginTop: -8,
  //   marginLeft: -12,
  //   "&:focus, &:hover, &$active": {
  //     boxShadow: "inherit",
  //   },
  // },
  // active: {},
  // valueLabel: {
  //   left: "calc(-50% + 4px)",
  // },
  // track: {
  //   height: 8,
  //   borderRadius: 4,
  // },
  // rail: {
  //   height: 8,
  //   borderRadius: 4,
  // },
})(Slider);

//elapsedTime,
//onChangeDispayFormat,
//totalDuration,

function PlayerControls(props: any) {
  const classes = useStyles();

  return (
    <div className={classes.controlsWrapper}>
      {/* bottom controls */}
      <Grid
        container
        direction="row"
        justify="space-between"
        alignItems="center"
        style={{ padding: 16 }}
      >
        <Grid item xs={12}>
          <PrettoSlider
            min={0}
            max={100}
            value={props.played * 100}
            onChange={props.onSeek}
            onMouseDown={props.onSeekMouseDown}
            onChangeCommitted={props.onSeekMouseUp}

          // ValueLabelComponent={(...props) => ( <ValueLabelComponent {...props} value={elapsedTime} /> )}
          />
        </Grid>
        {/* <Grid item>
          <Grid container alignItems="center" direction="row">
            <IconButton className={`${classes.bottomIcons} previousbtn`}>
              <SkipPreviousIcon fontSize="medium" />
            </IconButton>

            <IconButton className={`${classes.bottomIcons} playbtn`}
              onClick={props.onPlayPause}
            >
              {props.playing ? (
                <PauseIcon fontSize="medium" />
              ) : (
                <PlayArrowIcon fontSize="medium" />
              )}
            </IconButton>
            <IconButton className={`${classes.bottomIcons} nextbtn`}>
              <SkipNextIcon fontSize="medium" />
            </IconButton>

            <div className="volumeSec">
              <IconButton className={`${classes.bottomIcons} volumebtn`}
                onClick={props.onMute}
              >
                {props.muted ? (
                  <VolumeOff fontSize="medium" />
                ) : (
                  <VolumeUpIcon fontSize="medium" />
                )}

              </IconButton>

              <Slider
                min={0}
                max={100}
                value={props.volume * 100}
                className={`${classes.volumeSlider} volumeComp`}
                onChange={props.onVolumeChange}
                onChangeCommitted={props.onVolumeSeekUp}
              />
            </div>

            <Button
              variant="text"
              style={{ color: "#fff", marginLeft: 16 }}
            >
              <Typography>
              </Typography>
            </Button>
          </Grid>
        </Grid> */}
        {/* <Grid item>
          <IconButton
            className={`${classes.bottomIcons} fullscreen`}
          >
            <FullScreenIcon fontSize="medium" />
          </IconButton>
        </Grid> */}
      </Grid>
    </div>

  );
}
PlayerControls.propTypes = {

  onPlayPause: PropTypes.func,
  playing: PropTypes.bool,
  muted: PropTypes.bool,
  onMute: PropTypes.func,
  onVolumeChange: PropTypes.func,
  onVolumeSeekUp: PropTypes.func,
  volume: PropTypes.number,
  played: PropTypes.number,
  onSeek: PropTypes.func,
  onSeekMouseDown: PropTypes.func,
  onSeekMouseUp: PropTypes.func,
};
export default PlayerControls
