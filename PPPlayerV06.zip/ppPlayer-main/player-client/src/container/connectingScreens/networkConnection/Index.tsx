import { useEffect } from 'react';
import ConnectScreen from "../../../common/uiComponents/ConnectScreen"
import logo from '../../../Images/PictPlay_logo.png';
import wifi from '../../../Images/wifi1.png';
import './Index.css';
import text from '../../../common/en_US.json';
import { UseForConnect } from "./hook";
import { logger } from '../../../logger';

const Index = () => {
    const { string,
        locationState,
        rebootCalled,
        setLocationState,
        setString,
        checkNetworkConnection, location } = UseForConnect()

    // useEffect(() => {
    //     switch (window.location.pathname) {
    //         case "/":
    //             setLocationState("");
    //             break;
    //     }
    // }, []);

    useEffect(() => {
        console.log(location, "location.state.redirectUrl");
        if (location.state && location.state === "fromConnect") {
            console.log(location, "location.state.redirectUrl");
            setString(text.scaningText);
            setLocationState("fromConnect");
        } else if (location.state === "availableNet") {
            console.log(location, "location.state.redirectUrl");
            setString(text.wificonfigurationSaved);
            setTimeout(() => {
                setString(text.wifiConfigurationText);
            }, 3000);
            setLocationState("availableNet");
        } else {
            setLocationState("");
            setTimeout(() => {
                setString(text.startingDevice);
            }, 3000);
            setTimeout(checkNetworkConnection, 3000);
        }
    }, [location]);

    return (<>
        <ConnectScreen
            imgSrc={(locationState === 'fromConnect' || locationState === 'availableNet' || string === text.wifiConfigurationText) ? wifi : logo}
            pageDescription={string}
            showLoader={(string === text.welcomeToPictplay || string === text.contentdownloadText || string === text.wifiConfigurationText || locationState === 'fromConnect' || locationState === 'availableNet') ? false : true}
            showButton={locationState === 'availableNet' ? true : false}
            buttonText={text.rebootText}
            rebootCalled={rebootCalled}
        />
    </>
    )
};
export default Index;