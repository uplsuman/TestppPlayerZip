import { useState, useEffect } from "react";
import text from "../../../common/en_US.json";
import { useHistory, useLocation } from "react-router-dom";
import { logger } from "../../../logger";
import { useDispatch, useSelector } from "react-redux";
import { contentList, getContentList } from "../../../redux/action";
import { RootState } from "../../../common/interfaces";

export const UseForConnect = () => {
  const [string, setString] = useState(text.welcomeToPictplay);
  const [locationState, setLocationState] = useState("");
  const history = useHistory();
  const location: any = useLocation();
  const dispatch = useDispatch();
  const [data, setData] = useState(text.welcomeToPictplay);

  const rebootCalled = () => {
    setString(text.wifiConfigurationText);
    setLocationState("");
  };

  const checkNetworkConnection = () => {
    setString(text.checkingNetwork);
    const reqstValues: object = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        authorization: localStorage.getItem("token"),
      },
    };
    fetch(
      `${process.env.REACT_APP_serverurl}/connection/isconnected`,
      reqstValues
    )
      .then((result) => result.json())
      .then((result) => {
        logger.info("isconnected", result);
        if (!result.error) {
          getDeviceinfo();
        } else {
          history.push({ pathname: "/connect" });
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const getDeviceinfo = () => {
    const reqstValues: object = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    };
    fetch(`${process.env.REACT_APP_serverurl}/devices/serial`, reqstValues)
      .then((result) => result.json())
      .then((result) => {
        logger.info("Device serial", result);
        if (!result.error) {
          setString(text.checkingForConfiguration);
          if (result?.result?.length > 0) {
            findOrRegisterDevice(result.result);
          }
          // findOrRegisterDevice("ASV3456U7RB3456HG")
          // findOrRegisterDevice("BTKTM120433PP258369")
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const findOrRegisterDevice = (serialNo: string) => {
    const reqstValues: object = {
      method: "POST",
      body: JSON.stringify({
        serialNumber: serialNo,
      }),
      headers: {
        "Content-Type": "application/json",
      },
    };
    fetch(`${process.env.REACT_APP_serverurl}/devices/register`, reqstValues)
      .then((result) => result.json())
      .then((result) => {
        if (!result.error) {
          dispatch({ type: "DEVICE_DETAILS", data: result.result });
          if (result.result?.id) {
            setString(text.checkForContent);
            findContentToplay(result.result?.deviceId);
          } else {
            history.push({ pathname: "/device" });
          }
        }
      })
      .catch((err) => {
        logger.error(err);
      });
  };

  const findContentToplay = (deviceId?: string) => {
    const reqstValues: object = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        authorization: localStorage.getItem("token"),
      },
    };
    fetch(`${process.env.REACT_APP_serverurl}/playlists?deviceId=${deviceId}`, reqstValues)
      .then((result) => {
        return result.json();
      })
      .then((result) => {
        if (!result.error) {
          if (result?.result?.length > 0) {
            dispatch(contentList(result.result));
            history.push({
              pathname: "/player",
            });
          } else {
            history.push({
              pathname: "/noContent",
            });
          }
        }
      })
      .catch((err: string) => {
        logger.error(err);
      });
  }



  const checkDownloadStatus = () => {
    setTimeout(findContentToplay, 2000);
  }

  return {
    string,
    setString,
    locationState,
    rebootCalled,
    setLocationState,
    checkNetworkConnection,
    location
  };
};
