
import { useHistory } from "react-router-dom";

export const UseForDevice = () => {
    const history = useHistory()

    const addDevice = () => {
        history.push({
            pathname: '/welcome',
        });
    }

    return {
        addDevice
    };
};
