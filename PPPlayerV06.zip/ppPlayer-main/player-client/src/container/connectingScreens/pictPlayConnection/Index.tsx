//Pict Play screens goes here
import React, { useEffect, useState } from "react";
import "./Index.css";
import pictplay from "../../../Images/pictplay.png";
import wifi from "../../../Images/wifi.png";
import pc from "../../../Images/pc.png";
//import pcYou from '../../../Images/pcInner.png';
import Line from "../../../Images/Line.png";
import device1 from "../../../Images/device1.png";
import { UseForDevice } from "./hook";
import { logger } from "../../../logger";
import { useSelector } from "react-redux";
import { useHistory, useLocation } from "react-router-dom";
import { RootState } from "../../../common/interfaces";
import io from 'socket.io-client';
let socket: any = null;

const Index = () => {
  const [deviceId, setDeviceId] = useState([]);
  const [serialNo, setSerialNo] = useState("");

  const history = useHistory();
  const deviceData = useSelector((state: RootState) => state.deviceData);


  useEffect(() => {
    // getDeviceinfo()
    console.log("deviceData", deviceData);
    if (Object.keys(deviceData) && Object.keys(deviceData).length > 0) {
      let id = deviceData.deviceId;
      let idArr = id.split("");
      setDeviceId(idArr);
      setSerialNo(deviceData.serialNumber);
    }
    connectToSocket(deviceData.deviceId);
  }, [deviceData]);

  //socket connection
  const connectToSocket = (deviceId: string) => {
    logger.info('deviceId', deviceId)
    if (deviceId) {
      socket = io.connect(process.env.REACT_APP_SOCKET_URL, {
        reconnection: true,
        query: { deviceId: deviceId },
      });

      socket.on("deviceNotification", (data: any) => {
        logger.info('data', data)
        let username = data?.result?.user?.name
        history.push({ pathname: "/welcome", state: { username: username, deviceId: deviceId } })
      });

      return function cleanup() {
        if (socket !== null) {
          socket.disconnect();
        }
      };
    }
  };

  // const findOrRegisterDevice = (serialNo: string) => {
  //     const reqstValues: object = {
  //         method: 'POST',
  //         body: JSON.stringify({
  //             serialNumber: serialNo
  //         }),
  //         headers: {
  //             'Content-Type': 'application/json',
  //         }
  //     };
  //     fetch(`${process.env.REACT_APP_serverurl}/devices/register`, reqstValues)
  //         .then(result => result.json())
  //         .then(result => {
  //             if (!result.error) {
  //                 logger.info("DeviceId==>", result)
  //                 if (result?.result?.deviceId) {
  //                     let id = result?.result?.deviceId
  //                     let idArr = id.split("")
  //                     setDeviceId(idArr);
  //                     setSerialNo(serialNo);
  //                 }
  //             }

  //         })
  //         .catch(err => {
  //             logger.error(err);
  //         });
  // }

  const { addDevice } = UseForDevice();

  return (
    <div className="deviceMain">
      <div className="main_content_left">
        <div className="main_content_logo">
          <img alt="logo" src={pictplay} className="div_logo" />
        </div>
        <h3 className="div_h3">Visit website</h3>
        <div className="pictplayConnection_list">
          <div className="pictplayConnection_listImg">
            <img
              alt="wifi"
              src={wifi}
              className="pictplayConnection_list_img"
            />
            <img alt="lock" src={pc} className="pictplayConnection_list_img" />
            <img alt="link" src={pc} className="pictplayConnection_list_img" />
            <img alt="login" src={pc} className="pictplayConnection_list_img" />
          </div>
          <div className="pictplayConnection_listP">
            <p className="pictplayConnection_list_p">
              Open <span className="span_element">http://dev.pictplay.com</span>
            </p>
            <p className="pictplayConnection_list_p">
              Click on device,{" "}
              <span className="span_element" onClick={addDevice}>
                Add device
              </span>
            </p>
            <p className="pictplayConnection_list_p">
              Enter device Id appearing right to this screen
            </p>
            <p className="pictplayConnection_list_p">
              Get your portal connected to the player
            </p>
          </div>
        </div>
      </div>

      <div className="main_content_mid">
        <img alt="line" src={Line} />
      </div>

      <div className="main_content_right">
        <div className="rightBgImage">
          <img alt="device1" src={device1} className="right_img" />
          <div className="right_inside">
            <p className="inside_p">Your device id is</p>
            <div className="inside_img">
              {deviceId &&
                deviceId.map((id: string, idx: number) => {
                  return (
                    <div key={idx} className="inside_box">
                      <span className="box_text">{id ? id : "0"}</span>
                    </div>
                  );
                })}
              {/* <div className="inside_box"><span className="box_text">0</span></div>
                        <div className="inside_box"><span className="box_text">4</span></div>
                        <div className="inside_box"><span className="box_text">5</span></div>
                        <div className="inside_box"><span className="box_text">0</span></div>
                        <div className="inside_box"><span className="box_text">3</span></div> */}
            </div>
          </div>
        </div>

        <p className="right_p">
          Your device serial no is{" "}
          <span className="right_span">{serialNo ? serialNo : "--"}</span>
        </p>
      </div>
    </div>
  );
};
export default Index;
