import { combineReducers } from "redux";
import { deviceData, contentList } from '../redux/reducers'

const rootReducer = combineReducers({
    deviceData,
    contentList,
});

export default rootReducer;