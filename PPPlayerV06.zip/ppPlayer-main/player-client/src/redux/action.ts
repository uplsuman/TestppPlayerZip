import { logger } from "../logger";

export const CONTENT_LIST = "ALL_CONTENT_LIST";

export function contentList(data: any) {
  return {
    type: CONTENT_LIST,
    data: data,
  };
}

export function getContentList(location?: any, deviceId?: string) {
  return function (dispatch: any) {
    const reqstValues: object = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        authorization: localStorage.getItem("token"),
      },
    };
    fetch(
      `${process.env.REACT_APP_serverurl}/playlists?deviceId=${deviceId}`,
      reqstValues
    )
      .then((result) => {
        return result.json();
      })
      .then((result) => {
        if (!result.error) {
          console.log("content data", result?.result);
          if (result?.result?.length > 0) {
            dispatch(contentList(result.result));

          } else {
            location.push({
              pathname: "/noContent",
            });
          }
        }
      })
      .catch((err: string) => {
        logger.error(err);
      });
  };
}
