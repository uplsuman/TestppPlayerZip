export function deviceData(state = {}, action: any) {
    switch (action.type) {
        case "DEVICE_DETAILS":
            return action.data;
        default:
            return state;
    }
}

export function contentList(state = [], action: any) {
    switch (action.type) {
        case "ALL_CONTENT_LIST":
            return action.data;
        default:
            return state;
    }
}