import React, { Suspense } from "react";
import { Route, Switch } from "react-router-dom";
import NetworkConnection from '../container/connectingScreens/networkConnection/Index';
import NetworkScreen from '../container/networkScreens/Index';
import DeviceScreen from '../container/connectingScreens/pictPlayConnection/Index';
import WelcomeScreen from '../container/playerScreens/Index'
import NoContent from "../container/playerScreens/NoContent";
import AvailableNetworks from '../container/networkScreens/availableNetworks/Index';
import PlayerInterface from "../container/playerScreens/PlayerInterface";

const ROUTES = [
  {
    path: "/",
    key: "Connect",
    exact: true,
    component: () => (
      <Suspense fallback="">
        <NetworkConnection />
      </Suspense>
    ),
  },
  {
    path: "/connect",
    key: "Connect",
    exact: true,
    component: () => (
      <Suspense fallback="">
        <NetworkScreen />
      </Suspense>
    ),
  },
  {
    path: "/device",
    key: "Connect",
    exact: true,
    component: () => (
      <Suspense fallback="">
        <DeviceScreen />
      </Suspense>
    ),
  },
  {
    path: "/welcome",
    key: "Welcome",
    exact: true,
    component: () => (
      <Suspense fallback="">
        <WelcomeScreen />
      </Suspense>
    ),
  },
  {
    path: "/noContent",
    key: "NoContent",
    exact: true,
    component: () => (
      <Suspense fallback="">
        <NoContent />
      </Suspense>
    ),
  },
  {
    path: "/availableNetworks",
    key: "AvailableNetworks",
    exact: true,
    component: () => (
      <Suspense fallback="">
        <AvailableNetworks />
      </Suspense>
    )
  },
  {
    path: "/player",
    key: "Player",
    exact: true,
    component: () => (
      <Suspense fallback="">
        <PlayerInterface />
      </Suspense>
    )
  },
];

function RouteWithSubRoutes(route: any) {
  return (
    <Route
      path={route.path}
      exact={route.exact}
      render={(props: any) => (
        <route.component {...props} routes={route.routes} />
      )}
    />
  );
}

export function RenderRoutes({ routes }: any) {
  return (
    <Switch>
      {routes.map((route: any) => {
        return <RouteWithSubRoutes key={route.key} {...route} />;
      })}
      <Route component={() => <h1>Page Not Found!</h1>} />
    </Switch>
  );
}
export default ROUTES;
