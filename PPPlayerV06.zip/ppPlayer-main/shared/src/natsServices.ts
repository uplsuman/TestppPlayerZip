
import * as NATS from "nats";

import { logger }  from "./logger";




export default class NatsPlugin {
  constructor(private url: string, private nats: any = NATS) {}
  async publishMessage(topic: string, message: string) {
    const sc = this.nats.StringCodec();
    try {
      console.log(this.url);
      const nc = await this.nats.connect({ servers: this.url });
      logger.info(`Connected to NATS`);
      await nc.publish(topic, sc.encode(message));
      logger.info(`Published message ${message} on ${topic}`);

      const result = await nc.close();
      return result;
    } catch (err: any) {
      console.log(err);
      throw new Error(err);
    }
  }
  async subscribe(topic: string, next: Function) {
    const sc = this.nats.StringCodec();
    try {
      console.log(this.url);
      const nc = await this.nats.connect({ servers: this.url });
      logger.info(`Connected to NATS`);
      const sub = nc.subscribe(topic);
      (async (msub) => {
        console.log(
          `listening for ${msub.getSubject()} requests [uptime | stop]`
        );
        for await (const m of msub) {
          next(sc.decode(m.data));
        }
      })(sub);
    } catch (err: any) {
      console.log(err);
      throw new Error(err);
    }
  }
}


