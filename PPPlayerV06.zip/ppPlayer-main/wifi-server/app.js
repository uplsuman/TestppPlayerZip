const express = require("express");
const fs = require("fs");
const cors = require("cors");
const bodyParser = require("body-parser");
const exec = require("child_process");
const _ = require("lodash");
const { promisify } = require('util');
const execPromise = promisify(exec.exec)

require("dotenv").config();
var Wifi = require("rpi-wifi-connection");
var wifi = new Wifi();

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: "5mb" }));

// Get list of available network
app.get("/api/get/wifi", (req, res) => {
  try {
    wifi
      .scan()
      .then((ssids) => {
        var non_duplicated_data = _.uniqBy(ssids, "ssid");
        console.log("With unique ssid", non_duplicated_data);
        const filteredNetworks = non_duplicated_data.filter(
          (network) => network.ssid && network.ssid.length > 0
        );
        console.log("without blank ssid", filteredNetworks);
        return res.json({
          error: false,
          result: filteredNetworks,
          messasge: "Networks Found",
        });
      })
      .catch((error) => {
        console.log("Error-->", error);
        return res.json({
          error: true,
          result: error,
          message: "Networks not found",
        });
      });
  } catch (err) {
    console.log(err);
  }
});

// Connecting to networks
app.post("/api/select/wifi", (req, res) => {
  console.log("request body->>", req.body);

  const wifiSsid = req.body.wifiname;
  const wifiPassword = req.body.password;
  exec.execSync(
    `sudo ./tools/add-wifi.sh "${req.body.country}" "${wifiSsid}" "${wifiPassword}"`
  );
  exec.execSync(`sudo init 6`);

  fs.writeFileSync(
    `${InfoFilePath}local_data.json`,
    JSON.stringify(newLocalDataContent)
  );

  return res.json({
    error: false,
    result: wi_fi,
    message: "Connected!!",
  });
});

app.get("/api/wifi", async (req, res) => {
  try {
    const result = await execPromise("iwgetid --raw")
    if (result.stdout.length > 0) {
      let wifiName = result.stdout.split('/')[0]
      res.send({
        error: false,
        message: `Device is connected to ${wifiName}`,
      })
    }
    else {
      res.send({
        error: true,
        message: "Device is not connected to any network",
      })
    }
  }
  catch (err) {
    console.log(err)
    res.send({
      error: true,
      message: "Device is not connected to any network",
    })
  }
})

//port
const port = process.env.PORT || 8000;

//starting server
app.listen(port, () => {
  console.log(
    "WV Connect Server is listening on port (http://localhost:%d)",
    port
  );
});
