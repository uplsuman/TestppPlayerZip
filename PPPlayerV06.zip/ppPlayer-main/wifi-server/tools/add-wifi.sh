INTERACTIVE=True
CONFIG=/etc/network/interfaces
COUNTRY_STATUS=$1
WIFI_SSID=$2
WIFI_PASSWORD=$3
WIFI_SUPPLICANT=/etc/wpa_supplicant/wpa_supplicant.conf 
IS_HIDDEN=""

sed -i '/update_config=1/q0' $WIFI_SUPPLICANT
echo "country=$COUNTRY_STATUS " >> $WIFI_SUPPLICANT

echo "" >> $WIFI_SUPPLICANT

echo "network={" >> $WIFI_SUPPLICANT
echo "  ssid=\"$WIFI_SSID\" " >> $WIFI_SUPPLICANT
if [ -z "$WIFI_PASSWORD" ]; then
    echo "  key_mgmt=NONE " >>  $WIFI_SUPPLICANT
else
    echo "  psk=\"$WIFI_PASSWORD\" " >>  $WIFI_SUPPLICANT
fi

if [ ! -z "$IS_HIDDEN" ]; then
    echo "  scan_ssid=1 " >> $WIFI_SUPPLICANT
fi

echo "}" >>  $WIFI_SUPPLICANT

if grep -q "^iface eth0 inet" $CONFIG
then
    sudo ifdown  --force wlan0
    sudo ifup wlan0
else
    sudo ifconfig wlan0 down
    sudo ifconfig wlan0 up
fi

return 0