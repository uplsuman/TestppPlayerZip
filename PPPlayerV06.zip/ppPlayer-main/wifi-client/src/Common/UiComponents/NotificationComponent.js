import React from 'react';
import Snackbar from '@material-ui/core/Snackbar';
import Alert from '@material-ui/lab/Alert';
function NotificationComponent(props) {
    return (
        <div className="NotificationDiv">
            <Snackbar open={props.open} onClose={props.onClose} bodyStyle={{ backgroundColor: 'red', color: 'coral' }}>
                <Alert onClose={props.onClose} severity={props.severity} variant="filled">
                    {props.notificationMessage}
                </Alert>
            </Snackbar>
        </div >
    );
}

export default NotificationComponent;