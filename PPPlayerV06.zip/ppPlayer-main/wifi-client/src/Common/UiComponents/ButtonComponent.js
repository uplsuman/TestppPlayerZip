import React from "react";
import "./UiComponent.css";
import Button from "@material-ui/core/Button";
import CircularProgress from "@material-ui/core/CircularProgress";
import PropTypes from "prop-types";
import DoneAllIcon from "@material-ui/icons/DoneAll";

const ButtonComponent = (props) => {
    return (
        <div className={`buttoncomponent-start ${props.mainbuttonextra}`}>
            <Button
                className={
                    (props.disabled === true ? "disabledclass" : " ") +
                    " " +
                    (props.completed === true ? "loadingCompleted" : " ") +
                    " " +
                    "buttonclass" +
                    " " +
                    props.buttonextraclass
                }
                onClick={props.handleButton}
                disabled={props.disabled}
                startIcon={props.startIcon}
                variant={props.variant}
                fullWidth={props.fullWidth}
            >
                {props.loading === true
                    ? null
                    : props.btnimg && (
                        <img
                            src={props.btnimg}
                            className={`buttonimage ${props.buttonimgextracls}`}
                            alt="btnimg"
                        />
                    )}
                {props.loading === true
                    ? null
                    : props.btniconclass && (
                        <i className={props.btniconclass} aria-hidden="true"></i>
                    )}
                {props.loading === true ? (
                    <div className="loaderwithtxt">
                        <CircularProgress
                            size={15}
                            className="buttonprogressdesign"
                            color="white"
                        />
                        <span>{props.loadingTxt} </span>
                    </div>
                ) : (
                        props.buttontext
                    )}
                {props.completed === true ? (
                    <div className="loadingCompletecls">
                        <DoneAllIcon />
                        <span>{props.completTxt} </span>
                    </div>
                ) : null}
            </Button>
        </div>
    );
};

ButtonComponent.prototype = {
    handleButton: PropTypes.func,
    buttonextraclass: PropTypes.string,
    disabled: PropTypes.bool,
    inactive: PropTypes.bool,
    loading: PropTypes.bool,
    buttontext: PropTypes.string,
    btnimg: PropTypes.string,
    buttonimgextracls: PropTypes.string,
    btniconclass: PropTypes.string,
    loadingTxt: PropTypes.string,
    completed: PropTypes.string,
    completTxt: PropTypes.string,
};

export default ButtonComponent;
