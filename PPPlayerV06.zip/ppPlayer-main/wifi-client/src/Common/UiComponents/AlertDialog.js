import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import Icon from "@material-ui/core/Icon";
import DeleteIcon from "@material-ui/icons/Delete";
import "./UiComponent.css";
import ButtonComponent from "./ButtonComponent";
import text from "../Text.json";
import PropTypes from "prop-types";
import CloseIcon from "../../assets/icons/close.svg";

export default function AlertDialog(props) {
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleOk = () => {
    props.handleOk();
    handleClose();
  };

  return (
    <div>
      <Dialog
        className="modal-main"
        open={handleClickOpen}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        overflow="visible"
      >
        <div className="modal">
          <DialogContent className="modal-content">
            {/* Modal Header */}
            <DialogTitle className="modal-header">
              {/* <div className="icon-box">
                <DeleteIcon className="icon" />
              </div> */}
              <Button onClick={props.alertClose} className="close">
                {/* <Icon>close</Icon> */}
                <img
                  src={CloseIcon}
                  className="closeIcon"
                  alt="close"
                />
              </Button>
            </DialogTitle>
            {/* Modal Body */}
            <DialogContentText
              id="alert-dialog-description"
              className="modal-body"
            >
              <h2>{props.title}</h2>
              <h3>{props.subtitle}</h3>
            </DialogContentText>
            {/* Modal Footer */}
            <DialogActions className="modal-footer">
              <ButtonComponent
                mainbuttonextra="alert-close-btn"
                handleButton={props.alertClose}
                buttontext={text.cancelbtnText}
              />
              <ButtonComponent
                mainbuttonextra="alert-delete-btn"
                buttontext={text.OkbtnText}
                handleButton={handleOk}
              />
            </DialogActions>
          </DialogContent>
        </div>
      </Dialog>
    </div>
  );
}

AlertDialog.prototype = {
  alertClose: PropTypes.func,
  title: PropTypes.string,
  subtitle: PropTypes.string,
};
