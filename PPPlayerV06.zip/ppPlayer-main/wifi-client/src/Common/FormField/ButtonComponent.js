import React from "react";
import Button from "@material-ui/core/Button";
import CircularProgress from "@material-ui/core/CircularProgress";
import PropTypes from "prop-types";
// import DoneAllIcon from "@material-ui/icons/DoneAll";

const ButtonComponent = (props) => {
    return (
        <div className={"buttoncomponent-start" + " " + props.mainbuttonextra}>
            <Button
                className={
                    (props.disabled === true ? "disabledclass" : " ") +
                    " " +
                    (props.completed === true ? "loadingCompleted" : " ") +
                    " " +
                    "buttonclass" +
                    " " +
                    props.buttonextraclass
                }
                onClick={props.handleButton}
                disabled={props.disabled}
                startIcon={props.startIcon}
                variant={props.variant}
                fullWidth={props.fullWidth}
            >
                {props.imgSrc &&
                    <img src={props.imgSrc} alt='img' />
                }
                {props.completTxt &&
                    <div className="loadingCompletecls">
                        <span>{props.completTxt} </span>
                    </div>
                }
            </Button>
        </div>
    );
};

ButtonComponent.prototype = {
    handleButton: PropTypes.func,
    buttonextraclass: PropTypes.string,
    disabled: PropTypes.bool,
    inactive: PropTypes.bool,
    loading: PropTypes.bool,
    buttontext: PropTypes.string,
    btnimg: PropTypes.string,
    buttonimgextracls: PropTypes.string,
    btniconclass: PropTypes.string,
    loadingTxt: PropTypes.string,
    completed: PropTypes.string,
    completTxt: PropTypes.string,
};

export default ButtonComponent;
