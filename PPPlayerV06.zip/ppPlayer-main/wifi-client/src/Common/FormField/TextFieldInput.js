import React from "react";
import "./formfield.css";
import { InputLabel, IconButton, FilledInput, FormHelperText, InputAdornment } from '@material-ui/core';
import PropTypes from 'prop-types';
import { Visibility, VisibilityOff, ErrorOutlined } from '@material-ui/icons';

/**
 * PasswordField Component will be used to render the password Field input
 * 
 * @component
 * 
 */
function PasswordField(props) {

    const handleChange = (event) => {
        props.onChange(event.target.name, event.target.value);
    }


    return (
        <div className={"textfieldinput " + props.extracls}>
            {props.inputLabel ? (
                <InputLabel
                    shrink
                    htmlFor='bootstrap-input'
                    required={props.required}
                    className={'textinputlabel' + ' ' + props.extralabelcls}
                >
                    {props.inputLabel}
                </InputLabel>
            ) : null}
            <FilledInput
                // disabled={props.disabled}
                defaultValue={props.defaultValue}
                className={"InputFormField " + props.extracls + (props.errorText && ' inputmaskerror')}
                name={props.textinputname}
                fullWidth={props.fullwidthState}
                placeholder={props.placeholder}
                error={props.error}
                value={props.value}
                autoComplete='off'
                aria-autocomplete='off'
                id="filled-adornment-password"
                type={props.type}
                onChange={handleChange}
            />
        </div>
    );

}
PasswordField.prototype = {
    inputLabel: PropTypes.string,
    extralabelcls: PropTypes.string,
    textnewclass: PropTypes.string,
    textinputname: PropTypes.string,
    disabled: PropTypes.bool,
    defaultValue: PropTypes.string,
    error: PropTypes.bool,
    fullwidthState: PropTypes.bool,
    placeholder: PropTypes.string,
    onChange: PropTypes.func,
    inputProps: PropTypes.object,
    required: PropTypes.bool,
    value: PropTypes.string,
}


export default PasswordField;