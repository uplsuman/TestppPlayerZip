import React, { useEffect } from "react";
import "./formfield.css";
import { withStyles } from "@material-ui/core/styles";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import InputBase from "@material-ui/core/InputBase";
import NativeSelect from "@material-ui/core/NativeSelect";
import PropTypes from "prop-types";
import { Select, MenuItem } from '@material-ui/core';

const BootstrapInput = withStyles((theme) => ({
  // root: {
  //   "label + &": {
  //     marginTop: theme.spacing(3),
  //   },
  // },
  input: {
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.background.paper,
    border: "1px solid #ced4da",
    fontSize: 16,
    padding: "17px 26px 17px 12px",
    transition: theme.transitions.create(["border-color", "box-shadow"]),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      borderRadius: 4,
      borderColor: " #80bdff",
      boxShadow: "0 0 0 0.2rem  rgba(0,123,255,.25)",
    },
  },
}))(InputBase);

// const useStyles = makeStyles((theme) => ({
//   //   formControl: {
//   //     margin: theme.spacing(1),
//   //     minWidth: 120,
//   //   },
//   selectEmpty: {
//     marginTop: theme.spacing(2),
//   },
// }));



export default function SelectField(props) {
  // const classes = useStyles();
  const [state, setState] = React.useState({
    age: "",
    name: "hai",
  });

  const handleChange = (event) => {
    const name = event.target.name;
    setState({
      ...state,
      [name]: event.target.value,
    });
    props.onChange(event.target.name, event.target.value);
  };

  return (
    <div>
      <FormControl
        fullWidth
        className={
          "selectfieldclass" +
          " " +
          (props.textnewclass ? props.textnewclass : "")
        }
      >
        <FormHelperText id="outlined-weight-helper-text">
          {props.label}
        </FormHelperText>
        <Select
          // native
          // native
          placeholder={props.placeholder}
          defaultValue={props.defaultValue}
          value={props.value}
          onChange={handleChange}
          displayEmpty
          name={props.textinputname}
          disabled={props.disabled}
          inputProps={props.flotingIcon}
        >
          {/* <MenuItem value="IN">India (IN)</MenuItem>
          <MenuItem value="US">United States (US)</MenuItem> */}
          {props.selectoptions && props.selectoptions.length > 0 && props.selectoptions.map((item, index) => {
            return (
              <MenuItem key={index} value={item.value}>
                {item.label}
              </MenuItem>
            );
          }
          )
          }
        </Select>
      </FormControl>
    </div>
  );
}

SelectField.prototype = {
  textnewclass: PropTypes.string,
  label: PropTypes.string,
  value: PropTypes.string,
  selectOptions: PropTypes.any,
};
