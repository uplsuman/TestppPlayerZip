import React, { useEffect, useState } from "react";
import "./Network.css";
import { Grid } from "@material-ui/core";
import reconnect from "../assets/icons/connect_to_a_network.svg";
// import SearchLogo from '../assets/images/connect/search.svg';
import text from "../Common/Text.json";
// import QrCode from "../assets/images/connect/qr.svg";
import wallviewlogo from '../assets/images/wall_view_logo_white_.png'
import { useHistory } from "react-router-dom";
import packageJSON from '../../package.json';
import axios from "axios";

const { APIBaseUrl } = require("../Constants/APIConstants");

function Reconnect(props) {
    let history = useHistory();
    const [qrCode, setQrCode] = useState("");
    const startPlayer = () => {
        axios
            .post(`${APIBaseUrl}/api/player`)
            .then(async (response) => {
                console.log(response)
                if (response.data) {
                    history.push("/blank");
                }
            })
            .catch((err) => {
                console.log("error", err);
                history.push("/blank");
            });
    }

    const checkContent = () => {
        axios
            .get(`${APIBaseUrl}/api/checkContent`)
            .then(async (response) => {
                console.log("checkIfDeviceIsRegistered", response);
                if (response.data.message === true) {
                    history.push("/blank");
                    startPlayer()
                }
                else {
                    console.log("error");
                    history.push("/network");
                }
            })
            .catch((err) => {
                console.log("error", err);
                // history.push("/noData");
            });
    }

    const checkIfDeviceInfoExist = () => {
        axios
            .get(`${APIBaseUrl}/api/checkDeviceInfoExistance`)
            .then(async (response) => {
                console.log("checkIfDeviceIsRegistered", response);
                if (response.data.error === false) {
                    checkContent();
                    // history.push("/blank");
                    // startPlayer()
                }
                else {
                    console.log("error");
                    history.push("/network");
                }
            })
            .catch((err) => {
                console.log("error", err);
                // history.push("/noData");
            });
    }

    useEffect(() => {
        (async () => {
            await axios.delete(`${APIBaseUrl}/api/network`);
        })();
        const updateNetwork = () => {
            if (window.navigator.onLine) {
                console.log("")
                history.push("/");
            } else {
                // history.push("/network");
            }
        };

        window.addEventListener("offline", updateNetwork);
        window.addEventListener("online", updateNetwork);
        console.log("settimeout")
        setTimeout(() => {
            console.log("settimeout function starts")
            checkIfDeviceInfoExist();
        }, 30000);
        return () => {
            window.removeEventListener("offline", updateNetwork);
            window.removeEventListener("online", updateNetwork);
        };
    }, []);

    useEffect(() => {
        GetQRCode();
    }, [])
    // Get QR API
    const GetQRCode = () => {
        axios
            .get(`${APIBaseUrl}/api/getQR`)
            .then(async (response) => {
                console.log("GetQRCode", response);
                if (response.data.error === false) {
                    console.log("GetQRCode", response.data);
                    setQrCode(response.data.result);
                    // history.push("/blank");
                    // startPlayer()
                }
                else {
                    console.log("error");
                }
            })
            .catch((err) => {
                console.log("error", err);
                // history.push("/noData");
            });
    }
    return (
        <div className="w-full fordashboard h-full reconnectMainDiv forreconnect">
            <div className="reconnectmain reaconnectpage">
                <Grid container spacing={0}>
                    <Grid item md={12} sm={6}>
                        <div className="reconnecttopsec">
                            <div className='reconnectFirstDiv'>
                                <img src={reconnect} className="reConnectImage" alt="reconnect" />
                                <h2 className='reconnect-main-heading'>{text.ConnectNetworkText}</h2>
                            </div>
                            <h2 className='ReconnectDeviceSubHeading'>{text.ConnectNetworkSubHeadingText} </h2>

                        </div>
                        <div className="cornerlogo">
                            <img src={wallviewlogo} />
                            <p>Version {packageJSON.version}</p>
                        </div>
                    </Grid>
                    <div className="ConnectLeftDiv middlearea">
                        <ul className="connectUlCls">
                            <li className='ConnectList'>{text.connectToWifiText} <span className='ConnectSpanCls'>{text.WiFiSSID}</span> {text.usepwText}  <span className='ConnectSpanCls'>{text.WiFiPass}</span> </li>
                        </ul>
                    </div>

                    <Grid container spacing={0} alignItems='center' className="reconnectbottomsec">
                        <Grid item md={6} sm={12}>
                            <div className="ConnectLeftDiv">
                                <ul className="connectUlCls">
                                    <li className='ConnectList'>Visit <span className='ConnectSpanCls'>{text.DeviceURL}</span></li>
                                </ul>
                            </div>
                        </Grid>
                        <Grid item md={6} sm={12}>
                            <div className="ConnectQRSec">
                                <img src={qrCode} className="QrCodeImage" alt="QrCode" />
                                <p className="ScanTextCls">{text.ScanQr}</p>
                                <div className="OrDiv">
                                    <p className="OrText">OR</p>
                                </div>
                            </div>

                        </Grid>
                    </Grid>
                </Grid>

            </div>
        </div>
    );
}

export default Reconnect;
