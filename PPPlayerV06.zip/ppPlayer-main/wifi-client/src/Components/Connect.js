import React, { useState, useEffect } from "react";
import { Grid } from "@material-ui/core";
// import { TextField } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import MuiAccordion from "@material-ui/core/Accordion";
import MuiAccordionSummary from "@material-ui/core/AccordionSummary";
import MuiAccordionDetails from "@material-ui/core/AccordionDetails";
// import Typography from "@material-ui/core/Typography";
// import { Button } from "@material-ui/core";
import wifiSignal from "../assets/icons/wifi.png";
import text from "../Common/Text.json";
import "./Connect.css";
// import PasswordField from "../Common/FormField/PasswordField";
// import SelectField from "../Common/FormField/SelectField";
import "./Network.css";
import { useHistory } from "react-router-dom";
import axios from "axios";
import arrow from "../assets/images/right-arrow.png";
import reconnect from "../assets/images/wifi-white.png";
// import ButtonComponent from "../Common/FormField/ButtonComponent";
import ConnectNetworkForm from "../Forms/ConnectNetworkForm";
import wallviewlogo from '../assets/images/wall_view_logo_white_.png'
import packageJSON from '../../package.json'
import NotificationComponent from "../Common/UiComponents/NotificationComponent";
import AlertDialog from "../Common/UiComponents/AlertDialog";

const { APIBaseUrl } = require("../Constants/APIConstants");

function Connect() {
    const [data, setData] = useState([]);
    const [openForm, setForm] = useState(false);
    const [wifi, setWifi] = useState({});
    const [password, setPassword] = useState("");
    const [country, setCountry] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [ssid, setSsid] = useState("");
    const [status] = useState([]);
    // const [setStatus] = useState([]);
    const [found, setFound] = useState(false);
    const [ssidInput, setSsidInput] = useState("");
    let history = useHistory();
    const [openDialog, setOpenDialog] = useState(false);
    const [active, setActive] = useState('');
    const [opennotification, setOpennotification] = React.useState(false);
    const [notificationType, setnotificationType] = useState("");
    const [notificationMessage, setnotificationMessage] = useState("");
    const messageHandler = (type, message) => {
        setOpennotification(true);
        setnotificationMessage(message);
        setnotificationType(type);
        setTimeout(() => {
            setOpennotification(false);
        }, 5000);
    };

    const handleClose = (event, reason) => {
        if (reason === "clickaway") {
            return;
        }
        setOpennotification(false);
    };
    const closeAlert = () => {
        setOpenDialog(false);
    };



    const handleChangePassword = (name, value, index, data) => {
        setWifi((prev) => {
            return {
                ...prev,
                [name]: value,
                wifiname: data.ssid,
            };
        });
    };

    /**
     * Changes done by Abhijit
     * Uncommented below to remove error
     */
    useEffect(() => {
        const updateNetwork = () => {
            if (window.navigator.onLine) {
                history.push("/");
            } else {
                document.getElementsByTagName('html')[0].remove();
                // history.push("/network");
            }
        };
        /** --- End uncommenting */

        window.addEventListener("offline", updateNetwork);
        window.addEventListener("online", updateNetwork);
        return () => {
            window.removeEventListener("offline", updateNetwork);
            window.removeEventListener("online", updateNetwork);
        };
    });

    //   window.addEventListener("offline", updateNetwork);
    //   window.addEventListener("online", updateNetwork);
    //   return () => {
    //     window.removeEventListener("offline", updateNetwork);
    //     window.removeEventListener("online", updateNetwork);
    //   };
    // });
    useEffect(() => {
        console.log(data, "edrftgyhsdgi");

        if (data.length < 1) {
            axios
                .get(`${APIBaseUrl}/api/get/wifi`)
                .then((response) => {
                    console.log(response)
                    if (response.data.error === false) {
                        console.log("success response", response.data.result);
                        setData(response.data.result);
                        // setData(data.result)
                        setFound(false);
                    }
                    else {
                        messageHandler("error", "Could not find any SSID. Please enter the SSID name.");
                        setFound(true);
                        openFormCalled()
                        console.log("error");
                        // history.push("/network");
                    }
                    // var data =
                    // {
                    //   error: false,
                    //   result: [
                    //     {
                    //       bssid: "04:95:e6:55:d6:c8",
                    //       frequency: 2432,
                    //       signalLevel: -35,
                    //       ssid: ":-) ",
                    //     },
                    //     {
                    //       bssid: "0c:80:63:94:84:3f",
                    //       frequency: 2432,
                    //       signalLevel: -45,
                    //       ssid: ":))",
                    //     },
                    //     {
                    //       bssid: "60:32:b1:e3:69:70",
                    //       frequency: 2457,
                    //       signalLevel: -67,
                    //       ssid: "TP-Link_Aravali1601",
                    //     }
                    //   ],
                    //   messasge: "Networks Found",
                    // }


                })
                .catch((err) => {
                    console.log("error", err);
                    setFound(true);
                    openFormCalled()
                });
        }
    }, [data]);

    const validateForm = () => {
        if (!country) {
            messageHandler('error', 'Please Select country');
        } else if (found === true && !ssidInput) {
            messageHandler('error', 'Please enter ssid');
        } else if (!password) {
            messageHandler('error', 'Please enter Password');
        } else {
            ClickToConfirm();
        }
    }

    const ClickToConfirm = () => {
        setOpenDialog(true);
    }
    const clickedOk = () => {
        setOpenDialog(false);
        connectWifi();
    }

    const connectWifi = () => {
        console.log(ssid, "clicked on connect", confirmPassword, "-", password);

        // if (password.toString() !== confirmPassword.toString()) {
        //   console.log("password didn't matched");
        //   alert("password didn't matched");
        // } else {
        console.log("connecting to network", {
            wifiname: ssid,
            password: password,
        });
        axios
            .post(`${APIBaseUrl}/api/select/wifi`, {
                wifiname: ssid?.length > 0 ? ssid : ssidInput,
                password: password,
                country: country,
            })
            .then(function (response) {
                console.log(response);
                history.push("/reboot", { wifiName: ssid?.length > 0 ? ssid : ssidInput });
            })
            .catch(function (error) {
                console.log(error);
            });
        // }
    };

    // console.log(status);
    const Accordion = withStyles({
        root: {
            border: "1px solid rgba(0, 0, 0, .125)",
            boxShadow: "none",
            "&:not(:last-child)": {
                borderBottom: 0,
            },
            "&:before": {
                display: "none",
            },
            "&$expanded": {
                margin: "auto",
            },
        },
        expanded: {},
    })(MuiAccordion);

    const AccordionSummary = withStyles({
        root: {
            backgroundColor: "rgba(0, 0, 0, .03)",
            borderBottom: "1px solid rgba(0, 0, 0, .125)",
            marginBottom: -1,
            minHeight: 56,
            "&$expanded": {
                minHeight: 56,
            },
        },
        content: {
            "&$expanded": {
                margin: "12px 0",
            },
        },
        expanded: {},
    })(MuiAccordionSummary);

    const AccordionDetails = withStyles((theme) => ({
        root: {
            padding: theme.spacing(2),
        },
    }))(MuiAccordionDetails);

    const [expanded, setExpanded] = React.useState();

    const handleChange = (panel) => (event, newExpanded) => {
        setExpanded(newExpanded ? panel : false);
        setWifi({});
    };

    const openFormCalled = (data) => {
        setActive(data);
        setForm(true);
    };
    const renderWifiList = () => {
        return data.map((network, idx) => {
            return (
                <div
                    key={network.ssid}
                    className={
                        (active === idx ? "activeWifi" : "") + " " + "ConnectWifiDiv"
                    }
                    onClick={() => {
                        openFormCalled(idx);
                        setSsid(network.ssid);
                    }}
                >
                    <img src={wifiSignal} className="WifiImage" alt="wifi" />
                    <div className="ConnectWifiNetworkDiv">
                        <p className="ConnectWifiNetworkName">{network.ssid}</p>

                        <p className="ConnectWifiNetworkStatus"> Secured</p>
                    </div>
                </div>
            );
        });
    };
    const gotoBack = () => {
        setForm(false)
    }


    return (
        <div
            className="reconnectMainDiv availableWifiMain"
        >
            <div className={openForm === true ? "AvilableWifisecSecondDiv" : "AvilableWifiSecondDiv"}>
                {/* for responsive header start */}
                <div className="connecttopsec hidden-md">
                    {openForm === true ?
                        <>
                            <div className="backsec" onClick={gotoBack}>
                                <div className="backimg">
                                    <img src={arrow} />
                                </div>
                                <p>Back</p>
                            </div>
                            <div className="reconnectFirstDiv">
                                <img src={reconnect} className="reConnectImage" alt="reconnect" />
                                <h2 className="reconnect-main-heading getlist">
                                    {text.connectToText} <span> {ssid?.length > 0 ? ssid : "Network"}</span>
                                </h2>
                            </div>
                            <h2 className="CnctDeviceSubHeading">{text.connectwifiSubText} </h2>
                        </>
                        :
                        <>
                            <div className="reconnectFirstDiv connecttopsecmob">
                                <h2 className="reconnect-main-heading">{text.availableWifi}</h2>
                            </div>
                            <h2 className="CnctDeviceSubHeading">{text.listOfNetText}</h2>
                        </>
                    }
                </div>
                {/* for responsive header start */}

                <div className="connecttopsec hidden-xs">
                    <div className="reconnectFirstDiv">
                        <h2 className="reconnect-main-heading">{text.availableWifi}</h2>
                    </div>
                    <h2 className="CnctDeviceSubHeading">{text.listOfNetText}</h2>
                </div>
                <div className="cornerlogo">
                    <img src={wallviewlogo} />
                    <p>Version {packageJSON.version}</p>
                </div>
                <div className="ConnectWifiPageMainDiv connectBelowSec">
                    <Grid container spacing={6} >
                        <Grid item md={6} xs={12}>

                            <div
                                className="ConnectScrollDiv"
                                style={{
                                    maxHeight: parseInt(window.innerHeight) - 220,
                                    overflowY: "auto", overflowX: 'hidden'
                                }}
                            >

                                <div className={openForm === true ? 'connectWifiMainDiv hidden-xs' : "connectWifiMainDiv"}>
                                    {renderWifiList()}


                                </div>
                            </div>
                        </Grid>

                        {openForm === true && (
                            <Grid item md={6} xs={12} >
                                <ConnectNetworkForm
                                    onCountryChange={(name, value) => setCountry(value)}
                                    onChange={(name, value, index) => setPassword(value)}
                                    onSsidChange={(name, value) => setSsidInput(value)}
                                    confirmOnChange={(name, value, index) => setConfirmPassword(value)}
                                    handleButton={validateForm}
                                    ssidFound={found}
                                />

                            </Grid>
                        )}
                    </Grid>
                </div>
            </div>
            {openDialog === true && (
                <AlertDialog
                    subtitle={["Device will be connected to ", <span className="BoldContent">{(ssid?.length > 0 ? ssid : ssidInput)}</span>, " and will reboot"]}
                    alertClose={closeAlert}
                    handleOk={() => clickedOk()}
                />
            )}
            <NotificationComponent
                open={opennotification}
                onClose={handleClose}
                severity={notificationType}
                notificationMessage={notificationMessage}
            />
        </div>

        //  <Grid container spacing={0} className="ConnectSecondSec ConnectpdBtm">
        //     <Grid item md={6} sm={12}>
        //       <div
        //         className="ConnectScrollDiv"
        //         style={{ maxHeight: window.innerHeight - 380, overflowY: "auto" }}
        //       >
        //         <div className="ConnectWifiPageMainDiv">
        //           <div className="connectWifiMainDiv">
        //             <div>
        //               {data.map((m, index) => {
        //                 return (
        //                   <Accordion
        //                     square
        //                     expanded={expanded === index}
        //                     onChange={handleChange(index)}
        //                   >
        //                     <AccordionSummary
        //                       aria-controls="panel1d-content"
        //                       id="panel1d-header"
        //                     >
        //                       <Typography>
        //                         <div className="ConnectWifiDiv">
        //                           <img
        //                             src={wifiSignal}
        //                             className="WifiImage"
        //                             alt="wifi"
        //                           />
        //                           <div className="ConnectWifiNetworkDiv">
        //                             <p
        //                               className="ConnectWifiNetworkName"
        //                               key={index}
        //                             >
        //                               {m.ssid}
        //                             </p>

        //                             <p className="ConnectWifiNetworkStatus">
        //                               {" "}
        //                               Secured
        //                             </p>
        //                           </div>
        //                         </div>
        //                       </Typography>
        //                     </AccordionSummary>
        //                     <AccordionDetails>
        //                       <Typography>
        //                         <div style={{ display: "flex" }}>
        //                           <PasswordField
        //                             textnewclass="login-email-input"
        //                             inputLabel="Password"
        //                             type="password"
        //                             textinputname="password"
        //                             onChange={(name, value, index) =>
        //                               handleChangePassword(name, value, index, m)
        //                             }
        //                             required
        //                             value={wifi && wifi.password}
        //                             index={index}
        //                           />
        //                           <Button
        //                             variant="outlined"
        //                             size="small"
        //                             color="primary"
        //                             className="inputFieldButton"
        //                             onClick={() => connectWifi()}
        //                           >
        //                             Connect
        //                           </Button>
        //                         </div>
        //                       </Typography>
        //                     </AccordionDetails>
        //                   </Accordion>
        //                 );
        //               })}
        //             </div>
        //           </div>
        //         </div>
        //       </div>
        //     </Grid>

        //     <Grid item md={6} sm={12}>
        //       <div className="ScanQrMainDiv">
        //         <img src={QrCode} className="QrCodeImage" alt="QrCode" />

        //         <div className="qrImageWifiDiv">
        //           <h2 className="QrCodeInfoText">{text.scanText} </h2>
        //           <h2 className="qrImageWifiHeadingTag">{text.WifiText} </h2>
        //           <p className="qrImageWifiUrlTag">
        //             {text.VisitText}{" "}
        //             <span className="QrCodeSpan">{text.helpText}</span>{" "}
        //             {text.InfoText} <br />
        //             {text.ConnectText}
        //           </p>
        //         </div>
        //       </div>
        //     </Grid>
        //   </Grid> 
    );
}

export default Connect;
