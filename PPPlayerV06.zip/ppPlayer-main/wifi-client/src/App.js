import "./App.css";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Connect from "./Components/Connect";
function App() {
  return (
    <div style={{ height: "100%" }}>
      <BrowserRouter>
        <Switch>
          <Route exact path="/" component={Connect}></Route>
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
