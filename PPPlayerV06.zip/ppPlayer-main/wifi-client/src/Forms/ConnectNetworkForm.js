import React from "react";
import "../Components/Connect.css";
import text from "../Common/Text.json";
import SelectField from "../Common/FormField/SelectField";
import PasswordField from "../Common/FormField/PasswordField";
import arrow from "../assets/images/right-arrow.png";
import ButtonComponent from "../Common/FormField/ButtonComponent";
import TextFieldInput from "../Common/FormField/TextFieldInput";

function ConnectNetworkForm(props) {

    const countryOption = React.useState([
        { label: 'India (IN)', value: 'IN' },
        { label: 'United States (US)', value: 'US' }
    ])

    return (
        <div className={"FormWifiMainDiv"}>
            <SelectField
                label={text.countryText}
                textnewclass="login-email-input"
                onChange={props.onCountryChange} // Todo: Make this a common function
                name="country"
                // value={vendorId}
                selectoptions={countryOption[0]}
            />

            {props.ssidFound === true &&
                <TextFieldInput
                    inputLabel={text.ssidinputLabel}
                    placeholder={text.Ssidplaceholder}
                    fullwidthState="fullwidth"
                    extracls="mb-16 addbanername"
                    textinputname={props.textinputname}
                    // value={props.value}
                    onChange={props.onSsidChange}
                    required
                />
            }
            <PasswordField
                textnewclass="login-email-input"
                inputLabel={text.passwordText}
                type="password"
                textinputname="password"
                onChange={props.onChange}
                required
            // value={wifi && wifi.password}
            // index={index}
            />

            {/* <PasswordField
                textnewclass="login-email-input"
                inputLabel={text.confirmPasswordText}
                type="password"
                textinputname="password"
                onChange={props.confirmOnChange}
                required
            // value={wifi && wifi.password}
            // index={index}
            /> */}

            <ButtonComponent imgSrc={arrow} handleButton={props.handleButton} />
        </div>
    );
}

export default ConnectNetworkForm;
